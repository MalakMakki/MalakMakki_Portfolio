

#the second one
'''import socket
import sys

# Server configuration
HOST = '127.0.0.1'
PORT = 65432

def receive_message(connection):
    data = connection.recv(1024)
    return data.decode()

def send_message(connection, message):
    connection.sendall(message.encode())

def play_game(connection):
    while True:
        received_data = receive_message(connection)
        print(received_data)
        if "Congratulations" in received_data:
            print("Congratulations! You won the game!")
            break
        elif "Game over" in received_data:
            print("Game over! Your opponent has won.")
            break
        else:
            guess = input("Guess a letter: ")
            send_message(connection, guess)


def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        try:
            client_socket.connect((HOST, PORT))
            print("Connected to the server.")

            while True:
                data = receive_message(client_socket)
                print(data)
                if "Welcome" in data:
                    play_game(client_socket)
                    break

        except ConnectionRefusedError:
            print("Connection refused. Please ensure the server is running.")
            sys.exit(1)

        except KeyboardInterrupt:
            print("\nClient is exiting...")
            sys.exit(0)

if __name__ == "__main__":
    main()'''

# the first one
'''import socket

# Server configuration
HOST = '127.0.0.1'
PORT = 65432

# Create a socket
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
    # Connect to server
    client_socket.connect((HOST, PORT))

    while True:
        # Receive data from server
        data = client_socket.recv(1024)
        print("Server:", data.decode())

        # Check if the game is over or if congratulations message is received
        if "Congratulations!" in data.decode():
            break
        elif "Game over" in data.decode():
            break
        
        # Prompt the player to guess a letter
        guess = input("Your guess: ")

        # Send the guess to the server
        client_socket.sendall(guess.encode())

        # Receive response from server
        response = client_socket.recv(1024)
        print("Server:", response.decode())'''

import socket

# Server configuration
HOST = '192.168.1.1'
PORT = 65432

# Create a socket
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
    try:
        # Connect to server
        client_socket.connect((HOST, PORT))
        print("\n<<<<<< HangMan Game >>>>>>")
        print("\nConnected to the server Successfully.\n\n"
    "The game requires the presence of 2 players. Here's how it works:\n\n"
    "If you are the first player:\n"
    " - The game will not begin until another player joins.\n"
    " - Please wait for another player to join.\n\n"
    "If you are the second player:\n"
    " - The game will begin immediately.\n"
    " - All rules of the game will be provided once the required number of players has been reached.\n")
         # Receive player ID from server
        player_id = client_socket.recv(1024).decode()
        print("You are Player ", player_id)


        


        # Game loop
        while True:
            # Receive data from server
            data = client_socket.recv(1024).decode()

            # Print server response
            print("Server:", data)

            # Check if the game is over
            if "Congratulations!" in data or "Game over" in data:
                break
            
            # Prompt the player to guess a letter
            guess = input("Your guess: ")

            # Send the guess to the server
            client_socket.sendall(guess.encode())

            # Receive response from server
            response = client_socket.recv(1024).decode()
            print("Server:", response)

    except ConnectionRefusedError:
        print("Connection refused. Please ensure the server is running.")
    except KeyboardInterrupt:
        print("\nClient is exiting...")
