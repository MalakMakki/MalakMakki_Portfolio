import socket
import random
import threading

# Server configuration
HOST = '192.168.1.1'
PORT = 65432

# List of words for the game
words = ["apple", "banana", "orange", "grape", "berry", "lemon"]

# Flag to indicate if the game is over
game_over = False

def send_message(connection, message):
    connection.sendall(message.encode())

def handle_client(connection, player_number, selected_word, revealed_letters, guessed_letters, game_state, other_connection):
    global game_over
    
    print(f"Player {player_number} connected. Selected word: {selected_word}")

    # Send player ID to client
    send_message(connection, str(player_number))

    connection.sendall(f'''Welcome to the <<HangMan>> Game !\nYou are 2 players in this game.\nBoth players must guess letters continuously until one player guesses all letters in the mystery word.\n\nThe word has {len(selected_word)} letters. Let's start\n'''.encode())

    if player_number == 2:
        # Notify both players that the second player has joined
        send_message(connection, "Player 2 has joined. The game will start now.")
        send_message(other_connection, "Player 2 has joined. The game will start now.")

    while True:
        data = connection.recv(1024)
        if not data:
            break

        guessed_letter = data.decode()
        print(f"Player {player_number} guessed: {guessed_letter}")

        if guessed_letter in guessed_letters:
            send_message(connection, "Pay attention !!! You already guessed this letter. Try again.")
            send_message(connection, f"Word: {' '.join(revealed_letters)}")
            continue

        guessed_letters.append(guessed_letter)

        if guessed_letter in selected_word:
            send_message(connection, f"Correct guess!! The letter '{guessed_letter}' is in the word.")
            for i, letter in enumerate(selected_word):
                if letter == guessed_letter:
                    revealed_letters[i] = guessed_letter

            if '_' not in revealed_letters:
                if not game_over:
                    game_state["winner"] = player_number
                    send_message(connection, "Congratulations! You guessed the word! Good Job ^_^")
                    send_message(other_connection, "Opponent has guessed the word. Game over *_*")
                    game_over = True
        else:
            send_message(connection, f"Incorrect guess!")

        send_message(connection, f"Word: {' '.join(revealed_letters)}")

    connection.close()

def main():
    global game_over

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((HOST, PORT))
        server_socket.listen()

        print("Server is listening for connections...")

        player_count = 0
        connections = []

        while True:
            if player_count < 2:
                connection, address = server_socket.accept()
                player_count += 1
                connections.append(connection)
                print(f"Player {player_count} connected from {address}")

                if player_count == 2:
                    selected_word = random.choice(words)
                    game_state = {"winner": None}
                    threading.Thread(target=handle_client, args=(connections[0], 1, selected_word, ['_' for _ in selected_word], [], game_state, connections[1])).start()
                    threading.Thread(target=handle_client, args=(connections[1], 2, selected_word, ['_' for _ in selected_word], [], game_state, connections[0])).start()
            else:
                print("\nMaximum number of players reached.")
                break

        for thread in threading.enumerate():
            if thread != threading.main_thread():
                thread.join()

if __name__ == "__main__":
    main()
