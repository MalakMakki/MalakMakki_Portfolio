


'''#after animation
import sys
import socket
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget, QTextEdit, QMessageBox, QGraphicsOpacityEffect
from PyQt5.QtCore import QThread, pyqtSignal, QPropertyAnimation, QEasingCurve

# Server configuration
HOST = '127.0.0.1'
PORT = 65432

class ClientThread(QThread):
    message_received = pyqtSignal(str)
    connected = pyqtSignal()
    player_id_received = pyqtSignal(str)
    game_over = pyqtSignal()

    def __init__(self, host, port):
        super().__init__()
        self.host = host
        self.port = port
        self.client_socket = None

    def run(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
            self.client_socket = client_socket
            try:
                client_socket.connect((self.host, self.port))
                self.connected.emit()

                player_id = client_socket.recv(1024).decode()
                self.player_id_received.emit(player_id)

                while True:
                    data = client_socket.recv(1024).decode()
                    self.message_received.emit(data)
                    if "Congratulations!" in data or "Game over" in data:
                        self.game_over.emit()
                        break
            except ConnectionRefusedError:
                self.message_received.emit("Connection refused. Please ensure the server is running.")
            except KeyboardInterrupt:
                self.message_received.emit("\nClient is exiting...")

    def send_guess(self, guess):
        if self.client_socket:
            self.client_socket.sendall(guess.encode())

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("The Maze of Letters")

        self.layout = QVBoxLayout()

        self.info_label = QLabel("Connecting to the server...")
        self.layout.addWidget(self.info_label)

        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.layout.addWidget(self.output_text)

        self.guess_input = QLineEdit()
        self.guess_input.setPlaceholderText("Enter your guess")
        self.layout.addWidget(self.guess_input)

        self.send_button = QPushButton("Send Guess")
        self.send_button.clicked.connect(self.send_guess)
        self.layout.addWidget(self.send_button)

        self.container = QWidget()
        self.container.setLayout(self.layout)
        self.setCentralWidget(self.container)

        # Animation for the info label
        self.fade_animation = QPropertyAnimation(self.info_label, b"opacity")
        self.fade_animation.setDuration(1000)
        self.fade_animation.setStartValue(1.0)
        self.fade_animation.setEndValue(0.0)
        self.fade_animation.setEasingCurve(QEasingCurve.InOutQuad)

        self.client_thread = ClientThread(HOST, PORT)
        self.client_thread.message_received.connect(self.display_message)
        self.client_thread.connected.connect(self.on_connected)
        self.client_thread.player_id_received.connect(self.on_player_id_received)
        self.client_thread.game_over.connect(self.on_game_over)
        self.client_thread.start()

    def display_message(self, message):
        self.output_text.append(message)

    def on_connected(self):
        self.fade_animation.start()  # Start the fade animation when connected
        self.info_label.setText("Connected to the server.")

    def on_player_id_received(self, player_id):
        self.output_text.append(f"You are Player {player_id}")

    def on_game_over(self):
        self.guess_input.setDisabled(True)
        self.send_button.setDisabled(True)
        QMessageBox.information(self, "Game Over", "The game has ended.")

    def send_guess(self):
        guess = self.guess_input.text()
        if guess:
            self.client_thread.send_guess(guess)
            self.guess_input.clear()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
'''



# after animation
import sys
import socket
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget, QTextEdit, QMessageBox, QGraphicsOpacityEffect
from PyQt5.QtCore import QThread, pyqtSignal, QPropertyAnimation, QEasingCurve

# Server configuration
HOST = '192.168.1.1'
PORT = 65432

class ClientThread(QThread):
    message_received = pyqtSignal(str)
    connected = pyqtSignal()
    player_id_received = pyqtSignal(str)
    game_over = pyqtSignal()

    def __init__(self, host, port):
        super().__init__()
        self.host = host
        self.port = port
        self.client_socket = None

    def run(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
            self.client_socket = client_socket
            try:
                client_socket.connect((self.host, self.port))
                self.connected.emit()

                player_id = client_socket.recv(1024).decode()
                self.player_id_received.emit(player_id)

                while True:
                    data = client_socket.recv(1024).decode()
                    self.message_received.emit(data)
                    if "Congratulations!" in data or "Game over" in data:
                        self.game_over.emit()
                        break
            except ConnectionRefusedError:
                self.message_received.emit("Connection refused. Please ensure the server is running.")
            except KeyboardInterrupt:
                self.message_received.emit("\nClient is exiting...")

    def send_guess(self, guess):
        if self.client_socket:
            self.client_socket.sendall(guess.encode())

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("The Maze of Letters")

        self.layout = QVBoxLayout()

        self.info_label = QLabel("Connecting to the server...")
        self.layout.addWidget(self.info_label)

        self.message_label = QLabel("\nConnected to the server Successfully.\n-!- If you are the first player, please wait for another player to join. -!-\n-!- After 1 minute, you will reconnect to search for a player.-!-\n"
                                    "-!-If you are the second player, the game will begin immediately as the required number of players has been reached.-!-\n")
        self.layout.addWidget(self.message_label)

        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        self.layout.addWidget(self.output_text)

        self.guess_input = QLineEdit()
        self.guess_input.setPlaceholderText("Enter your guess")
        self.layout.addWidget(self.guess_input)

        self.send_button = QPushButton("Send Guess")
        self.send_button.clicked.connect(self.send_guess)
        self.layout.addWidget(self.send_button)

        self.container = QWidget()
        self.container.setLayout(self.layout)
        self.setCentralWidget(self.container)

        # Animation for the info label
        self.fade_animation = QPropertyAnimation(self.info_label, b"opacity")
        self.fade_animation.setDuration(1000)
        self.fade_animation.setStartValue(1.0)
        self.fade_animation.setEndValue(0.0)
        self.fade_animation.setEasingCurve(QEasingCurve.InOutQuad)

        self.client_thread = ClientThread(HOST, PORT)
        self.client_thread.message_received.connect(self.display_message)
        self.client_thread.connected.connect(self.on_connected)
        self.client_thread.player_id_received.connect(self.on_player_id_received)
        self.client_thread.game_over.connect(self.on_game_over)
        self.client_thread.start()

    def display_message(self, message):
        self.output_text.append(message)

    def on_connected(self):
        self.fade_animation.start()  # Start the fade animation when connected
        self.info_label.setText("Connected to the server.")

    def on_player_id_received(self, player_id):
        self.output_text.append(f"You are Player {player_id}")

    def on_game_over(self):
        self.guess_input.setDisabled(True)
        self.send_button.setDisabled(True)
        QMessageBox.information(self, "Game Over", "The game has ended.")

    def send_guess(self):
        guess = self.guess_input.text()
        if guess:
            self.client_thread.send_guess(guess)
            self.guess_input.clear()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
