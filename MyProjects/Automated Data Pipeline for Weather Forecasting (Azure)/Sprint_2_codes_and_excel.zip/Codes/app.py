from flask import Flask, request, jsonify
import requests
import pandas as pd
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)  

# Function to get season based on the month
def get_season(month):
    if month in [12, 1, 2]:
        return 'Winter'
    elif month in [3, 4, 5]:
        return 'Spring'
    elif month in [6, 7, 8]:
        return 'Summer'
    elif month in [9, 10, 11]:
        return 'Fall'
    else:
        return 'Unknown'

@app.route('/fetch-weather-data', methods=['POST'])
def fetch_weather_data():
    try:
        data = request.json
        start_date = data['start_date']
        end_date = data['end_date']

        api_url = "https://archive-api.open-meteo.com/v1/archive"
        params = {
            "latitude": 33.8886,  # Latitude for Beirut
            "longitude": 35.4950,  # Longitude for Beirut
            "start_date": start_date,  
            "end_date": end_date,      
            "hourly": "temperature_2m,pressure_msl,relative_humidity_2m,cloudcover,windspeed_10m,winddirection_10m"
        }

        response = requests.get(api_url, params=params)
        response.raise_for_status() 
        weather_data = response.json()

        records = []
        for index, hour_data in enumerate(weather_data['hourly']['time']):
            date = pd.to_datetime(hour_data)
            month = date.month

            records.append({
                'dt': hour_data,
                'temp': weather_data['hourly']['temperature_2m'][index],
                'pressure': weather_data['hourly']['pressure_msl'][index],
                'humidity': weather_data['hourly']['relative_humidity_2m'][index],
                'clouds': weather_data['hourly']['cloudcover'][index],
                'wind_speed': weather_data['hourly']['windspeed_10m'][index],
                'wind_deg': weather_data['hourly']['winddirection_10m'][index],
                'season': get_season(month) 
            })

        df = pd.DataFrame(records)

        file_path = 'weather_data.xlsx'

        if os.path.exists(file_path):
            existing_df = pd.read_excel(file_path)
            updated_df = pd.concat([existing_df, df], ignore_index=True)
            updated_df.to_excel(file_path, index=False)
        else:
            df.to_excel(file_path, index=False)  

        return jsonify({'message': 'Data collected successfully!'}), 200
    except Exception as e:
        return jsonify({'message': f'Error occurred: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True)
