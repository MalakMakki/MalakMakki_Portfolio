document.getElementById('weather-form').addEventListener('submit', async function (e) {
    e.preventDefault();
    
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;
    const responseMessage = document.getElementById('response-message');
    
    responseMessage.innerText = 'Fetching data...';
    
    const response = await fetch('http://127.0.0.1:5000/fetch-weather-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ start_date: startDate, end_date: endDate })
    });    
    
    
    const data = await response.json();
    responseMessage.innerText = data.message;
});
