async function getWeather() {
    const city = document.getElementById("cityInput").value;

    // Get backend URL from environment variable or use a fallback
    const backendUrl = window.BACKEND_API_URL || 'https://myflaskbackend.azurewebsites.net';
    const url = `${backendUrl}/get_weather?city=${city}`;

    try {
        console.log("Fetching weather data from:", url);
        const response = await fetch(url);

        if (!response.ok) {
            console.error("Response not OK:", response.statusText);
            throw new Error("City not found");
        }

        const data = await response.json();
        const weather = `Temperature in ${data.city}: ${data.temperature}°C, ${data.description}`;
        document.getElementById("weatherResult").innerText = weather;
    } catch (error) {
        console.error("Fetch error:", error);
        document.getElementById("weatherResult").innerText = "Error: " + error.message;
    }
}
