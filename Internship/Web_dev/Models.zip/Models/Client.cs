﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class Client
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public client_Type Type { get; set; }

        public Nullable<DateTime> Birthdate { get; set; }
       // public DateTime Birthdate { get; set; }
    }

    public enum client_Type
    {
        individual=1,
        organization=2
    }
}