angular.module('myApp4', ['ui.bootstrap'])

    .directive('typeSelector', function () {
        return {
            restrict: 'E',
            template: `
           
           <select name="Type" id="Type" style="padding: 8px;" ng-model="selectedType">
                      <option value=""></option>
                      <option value="Individual">Individual</option>
                      <option value="Organization">Organization</option>
             </select>  `,
            scope: {
                selectedType: '=' // Liaison bidirectionnelle pour la valeur s�lectionn�e
            },
            controller: function ($scope) {
                // La logique de r�cup�ration des donn�es du type va ici
                // Par exemple, vous pouvez avoir une fonction getData
                $scope.getData = function () {
                    var selectedType = $scope.selectedType;
                    console.log('Type s�lectionn� :', selectedType);


                }
            }
        };
    })
    .controller('MainController4', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {

        $scope.selectedType = ''; // Initialise la variable selectedType
        $scope.individualNumber = 0;
        $scope.organizationNumber = 0;

        function getClientCounts() {
            $http.get('/api/clients/getcount') 
                .then(function (response) {
                    $scope.individualNumber = response.data.IndividualCount;
                    $scope.organizationNumber = response.data.OrganizationCount;
                    console.log("individual:", individualNumber);
                    console.log("organization:", organizationNumber);


                })
                .catch(function (error) {
                    console.error('Erreur lors de la r�cup�ration des comptes de clients : ', error);
                });
        }

        // Appeler la fonction pour r�cup�rer les comptes de clients au chargement de la page
        getClientCounts();

        $scope.showIndividual = true;
        $scope.showOrganization = true;

            $scope.filter = function () {
                $scope.showIndividual = ($scope.selectedType === '' || $scope.selectedType === 'Individual');
                $scope.showOrganization = ($scope.selectedType === '' || $scope.selectedType === 'Organization');
            };        
    }]);
