angular.module('myApp6', ['ui.bootstrap'])
    .controller('loginSignUpController', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {

        
      
        console.log('userData dans signup avant api:', user);
       


            $http.post('/api/login/add', user)
                .then(function (response) {
                    console.log(response);

                    // Redirigez l'utilisateur vers la page "Home/HomePage" apr�s l'ajout r�ussi.
                    window.location.href = '/Home/HomePage';
                })
                .catch(function (error) {
                    console.log('Error adding user:', error);
                });
       

    }]);


