
angular.module('myApp1', ['ui.bootstrap'])
   

    /*.directive('typeSelector', function () {
        return {
            restrict: 'E', // Restrict usage to element tags
            template: `
           
            <select name="Type" id="Type" style="padding: 8px;" ng-model="typeSelection" ng-change="filterClientsByType()">
                <option value=""></option>
                <option value="Individual">Individual</option>
                <option value="Organization">Organization</option>
            </select>
        `,
            scope: {
                selectedType: '=', // Two-way binding for the selected type
                filterClients: '&' // Function to filter clients by type
            }
        };
    })*/
    .directive('typeSelector', function () {
        return {
            restrict: 'E',
            template: `
           
           <select name="Type" id="Type" style="padding: 8px;" ng-model="selectedType">
                      <option value=""></option>
                      <option value="Individual">Individual</option>
                      <option value="Organization">Organization</option>
             </select>  `,
            scope: {
                selectedType: '=' // Liaison bidirectionnelle pour la valeur s�lectionn�e
            },
            controller: function ($scope) {
                // La logique de r�cup�ration des donn�es du type va ici
                // Par exemple, vous pouvez avoir une fonction getData
                $scope.getData = function () {
                    var selectedType = $scope.selectedType;
                    console.log('Type s�lectionn� :', selectedType);


                }
            }
        };
      })
    .directive('phoneSelector', function () {
        return {
            restrict: 'E',
            template: `
           
           <select name="Phone" id="Phone" style="padding: 8px;" ng-model="selectedPhone">
                      <option value=""></option>
                      <option ng-repeat="phone in phones" value="{{phone.Number}}">{{phone.Number}}</option>

             </select>  `,
            scope: {
                selectedPhone: '=',// Liaison bidirectionnelle pour la valeur s�lectionn�e
                phones: '='
            },
            controller: function ($scope) {
                // La logique de r�cup�ration des donn�es du type va ici
                // Par exemple, vous pouvez avoir une fonction getData
                $scope.getData = function () {
                    var selectedPhone = $scope.selectedPhone;
                    console.log('Phone s�lectionn� :', selectedPhone);


                }
            }
        };
    })

    .filter('extractDate', function () {
        return function (input) {
            if (input instanceof Date) {
                // Utilisez la m�thode toISOString pour obtenir la date au format ISO 8601
                // et supprimez ensuite l'heure en conservant seulement la partie date.
                return input.toISOString().split('T')[0];
            }
            return input;
        };
    })
    .controller('MainController1', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {
      //  $scope.inputDatetime = ''; // Initialize the date input
        $scope.i = false;

        function formatBirthdate(birthdate) {
            if (!birthdate) return "N/A";
            var dateObj = new Date(birthdate)
            return dateObj.toLocalDateString();
        }
    
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        $scope.clients = []; // Initialisez le tableau pour stocker les clients

        var typeMapping = {
            1: 'Individual',
            2: 'Organization',
            '': 0,

        };

        $scope.types = ['Individual', 'Organization']; // Les options de s�lection de type


        // Chargez les clients � partir de l'API
        $http.get('/api/clients')
            .then(function (response) {
                var clients = response.data;

               /* clients.forEach(function (client) {
                    client.Type = typeMapping[client.Type]; // Convertir la valeur num�rique en nom convivial
                    //$scope.checkReservedNumbers(client); // Appel de la fonction pour chaque client individuellement
                    //console.log("reserved or not?", $scope.checkReservedNumbers(client));

                });*/
                clients.forEach(function (client) {
                    client.Type = typeMapping[client.Type]; // Convertir la valeur num�rique en nom convivial
                   // $scope.checkReservedNumbers(client).then(function (hasReservation) {
                      //  console.log('Client:', client.Name, 'has reservations:', client.hasReservation);
                    //});
                });


                $scope.clients = clients;

            })
            .catch(function (error) {
                console.log('Erreur lors du chargement des clients :', error);
            });


        $scope.SearchClients = function () {
            var params = {};

            // Ajoutez le crit�re de recherche par nom si un terme de recherche est sp�cifi�
            if ($scope.searchTerm) {
                params.filter = $scope.searchTerm;
            }

            // Ajoutez le crit�re de recherche par type si un type est s�lectionn�
            if ($scope.typeSelection) {
                var typeValue = $scope.typeSelection === 'Individual' ? 1 : 2;
                params.type = typeValue;
            }

            // Effectuez la requ�te GET vers l'API avec les param�tres de recherche
            $http.get('/api/clients/filter', { params: params })
                .then(function (response) {
                    var clients = response.data;

                    clients.forEach(function (client) {
                        client.Type = typeMapping[client.Type]; // Convertir la valeur du type
                    });

                    $scope.clients = clients;
                })
                .catch(function (error) {
                    console.log('Erreur lors de la recherche des clients :', error);
                });
        };

      

      

        /*function addClient(newClient) {
            console.log("in add the new client:", newClient);
          
           
            $http.post('/api/clients/add', newClient)
                .then(function (response) {
                   // $scope.clients.push(response.data);

                    $http.get('/api/clients')
                        .then(function (response) {
                            var clients = response.data;

                            clients.forEach(function (client) {
                                client.Type = typeMapping[client.Type]; // Convertir la valeur num�rique en nom convivial
                            });

                            $scope.clients = clients;
                        })
                        .catch(function (error) {
                            console.log('Erreur lors du chargement des clients :', error);
                        });


                })
                .catch(function (error) {
                    console.log('Error adding client:', error);
                });
        }
        */

        function addClient(newClient) {
            console.log("hello, kill shi mafroud sar abel");
           /* if (!newClient || !newClient.Name || !newClient.Type || (!newClient.Birthdate && newClient.Type=== 'Individual') ){
                alert("Please fill in all fields for the new client!");
                return; // Sortir de la fonction si des champs sont vides
            }*/
            var clientExists = $scope.clients.some(function (client) {
                return client.Name === newClient.Name && client.Type === newClient.Type && client.Birthdate === newClient.Birthdate;
            });

            if (clientExists) {
                alert("Client with these specifications already exists!");
                return;
            }
            // Ajoutez des validations suppl�mentaires au besoin

            $http.post('/api/clients/add', newClient)

                .then(function (response) {
                    alert("Client added successfully !");



                    // Traitez la r�ponse ici si n�cessaire
                    $http.get('/api/clients')
                        .then(function (response) {
                            var clients = response.data;
                            clients.forEach(function (client) {
                                client.Type = typeMapping[client.Type]; // Convertir la valeur num�rique en nom convivial
                            });
                            $scope.clients = clients;

                           // alert("Client added successfully 2!");

                        })
                        .catch(function (error) {
                            console.log('Erreur lors du chargement des clients :', error);
                        });
                })
                .catch(function (error) {
                    console.log('Erreur lors de l\'ajout du client :', error);
                });
        }


       

        function updateClient(Client, newClient) {
            var clientExists = $scope.clients.some(function (client) {
                return client.Name === newClient.Name && client.Type === newClient.Type && client.Birthdate === newClient.Birthdate;
            });

            if (clientExists) {
                alert("Client with these specifications already exists!");
                return;
            }
            var updatedClient = {
                Id: Client.Id,
                Name: newClient.Name,
                Type: newClient.Type,
                Birthdate: newClient.Birthdate
            };
            console.log("in edit:", newClient);

            $http.put('/api/clients/update', updatedClient)
           

                .then(function (response) {
                    console.log("success 1");

                  //  alert("Client edited successfully !");

                    /*if (response.Type === 'Organization') {
                        response.Birthdate = null;
                    }*/

                    $http.get('/api/clients')
                        .then(function (response) {
                            var clients = response.data;

                            clients.forEach(function (client) {
                                client.Type = typeMapping[client.Type]; // Convertir la valeur num�rique en nom convivial
                            });

                            $scope.clients = clients;
                            alert("Client edited successfully!");

                           // alert("Client edited successfully 2222222222 !");
                            console.log("success 2");

                        })
                        .catch(function (error) {
                            console.log('Erreur lors du chargement des clients :', error);
                        });
                })
                .catch(function (error) {
                    console.log('Erreur lors de la mise � jour du client :', error);
                });
        }


        $scope.openModal = function (isEdit, client) {

            var modalInstance = $uibModal.open({
                templateUrl: 'myModalContent1.html',
                controller: 'ModalController1',

                resolve: {
                    isEdit: function () {
                        return isEdit;
                    },
                    client: function () {
                        return client;
                    }
                }
            });
            modalInstance.result.then(function (result) {
                if (result !== undefined) {


                    if (isEdit) {
                        updateClient(client, result);
                    } else {

                        addClient(result);
                    }

                }
            });



        };



        /////////////////////////////////////////////////////////////////////////////////////////

        $scope.reservedPhoneNumbers = [];


        $scope.availablePhoneNumbers = [];
        $scope.addReservation = function (newReserve) {
            $http.post('/api/reservations/add', newReserve)
                .then(function (response) {
                    console.log(response);
                    alert("Successful Reservation!");

                })
                .catch(function (error) {
                    console.log('Error adding reservation:', error);

                });

        };

        $scope.updateReservation = function (updatedReserve) {
            console.log('updated reserve in update!!!!!!', updatedReserve),
            $http.post('/api/reservations/update', updatedReserve)
                .then(function (response) {
                    console.log(response);
                    alert("Successful Unreservation!");

                })
                .catch(function (error) {
                    console.log('Error updating reservation:', error);

                });

        };

        $http.get('/api/clients/unreserve')
            .then(function (response) {
                $scope.availablePhoneNumbers = response.data;
                console.log($scope.availablePhoneNumbers);
            })
            .catch(function (error) {
                console.log('Erreur lors du chargement des telephones non reserves :', error);
            });
            //////////////////////////////////////////////////////////////////////////////////
       /* $http.get('/api/phones').then(function (response) {
            $scope.phoneNumbers = response.data;
            $scope.availablePhoneNumbers = angular.copy($scope.phoneNumbers); // Copiez tous les num�ros disponibles

        });*/
       // console.log('client avant appel � openReservationModal :', client);

        $scope.openReservationModal = function (client) {
            console.log('client dans openReservationModal :', client);

            var modalInstance = $uibModal.open({
                template: ` <div class="modal-header">
                                    <h3 class="modal-title">Reservation</h3>
                                    <button type="button" class="close" ng-click="cancel()" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                           </div>
                           <div class="modal-body">
                                   <p>Select a number for reservation :</p>
                                   <phone-selector selected-phone="selectedPhoneNumber" phones="availablePhoneNumbers"></phone-selector>

                           </div>
                           <div class="modal-footer">
                                  <button class="btn btn-default" ng-click="cancel()">cancel</button>
                                  <button class="btn btn-primary" ng-click="ok()">save</button>
                           </div>
                         `,
                controller: 'ReservationModalController',
                resolve: {
                    availablePhoneNumbers: function () {
                        return $scope.availablePhoneNumbers; // Assurez-vous que la variable est correctement d�finie
                    },
                    client: function () {
                        console.log('!!!!!!!!!!!!!', client);
                        return client; // Passez les informations du client � la modal
                    }
                }
            });

         
            modalInstance.result.then(function (result) {
                console.log('Nouvelle r�servation de instance :', result);

            
                if (result !== undefined) {

                    $scope.addReservation(result);
                    

                }
            });

        };
       
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





      /* $scope.checkReservedNumbers = function (client) {
            console.log('client1:', client);
            // Envoie une requ�te HTTP GET � votre API avec le nom du client en tant que param�tre
            $http.get('/api/reservations/reservedForClient', { params: { ClientName: client.Name } })
                .then(function (response) {
                    console.log('client2:', client);

                    // La r�ponse contient les num�ros de t�l�phone r�serv�s
                    $scope.reservedPhoneNumbers = response.data;
                    console.log('le check:', response);
                    console.log('reservednumber:', $scope.reservedPhoneNumbers);
                    return $scope.reservedPhoneNumbers;
                  
};
                })
                .catch(function (error) {
                    // G�rez les erreurs ici
                    console.error('Erreur lors de la requ�te API :', error);
                });
        };*/
        /*$scope.checkReservedNumbers = function (client) {
            console.log('client1:', client);

            // Envoie une requ�te HTTP GET � votre API avec le nom du client en tant que param�tre
            $http.get('/api/reservations/reservedForClient', { params: { ClientName: client.Name } })
                .then(function (response) {

                    console.log('client2:', client);
                      $scope.reservedPhoneNumbers = response.data;
                    console.log('reservednumber:', $scope.reservedPhoneNumbers);

                    if ($scope.reservedPhoneNumbers.length > 0) {
                        return true;
            } else {
                       return false; }
                  
                })
                .catch(function (error) {
                    
                    console.error('Erreur lors de la requ�te API :', error);
                });
        };

    */



        $scope.checkReservedNumbers = function (client) {
            console.log('client1:', client);

            // Envoie une requ�te HTTP GET � votre API avec le nom du client en tant que param�tre
            return $http.get('/api/reservations/reservedForClient', { params: { ClientName: client.Name } })
                .then(function (response) {
                    console.log('client2:', client);
                    $scope.reservedPhoneNumbers = response.data;
                    console.log('reservednumber:', $scope.reservedPhoneNumbers);

                    // Mettez � jour la propri�t� hasReservation du client en fonction de la r�ponse de l'API
                    client.hasReservation = $scope.reservedPhoneNumbers.length > 0;

                })
                .catch(function (error) {
                    console.error('Erreur lors de la requ�te API :', error);
                });
        };

       


        $scope.openUnreservationModal = function (client) {
            console.log('client dans openUnreservationModal :', client);

            

                $http.get('/api/reservations/reservedNumberForClient', { params: { ClientName: client.Name } })
                    .then(function (response) {
                        console.log('client dans api:', client);

                        // La r�ponse contient les num�ros de t�l�phone r�serv�s
                        $scope.reservedPhoneNumbers = response.data;
                        console.log('length!!!', $scope.reservedPhoneNumbers.length);

                        console.log('la reponse de api:', response);
                        if (response) {
                            var modalInstance = $uibModal.open({
                                template: `
          <div class="modal-header">
             <h3 class="modal-title">Unreservation</h3>
             <button type="button" class="close" ng-click="close()" aria-label="Close"><span aria-hidden="true">&times;</span></button>
         </div>
         <div class="modal-body">
            <p>Select a number for unreservation :</p>
            <phone-selector selected-phone="selectedNumber" phones="reservedPhoneNumbers"></phone-selector>

         </div>
         <div class="modal-footer">
            <button class="btn btn-default" ng-click="close()">cancel</button>
            <button class="btn btn-primary" ng-click="ok(selectedNumber)">save</button>
         </div>`,

                                controller: 'UnreservationModalController',
                                resolve: {
                                    reservedPhoneNumbers: function () {
                                        return $scope.reservedPhoneNumbers; // Assurez-vous que la variable est correctement d�finie
                                    },
                                    client: function () {
                                        return client;
                                    }
                                }
                            });

                            modalInstance.result.then(function (result) {
                                console.log('Unreservation instance result:', result);

                                if (result !== undefined) {
                                    $scope.updateReservation(result);

                                }
                            });
                        }

                        else {

                            $scope.reservedPhoneNumbers = null;


                        };
                        // console.log('reservednumber:', $scope.reservedPhoneNumbers);
                        //return $scope.reservedPhoneNumbers;
                    })
                    .catch(function (error) {
                        // G�rez les erreurs ici
                        console.error('Erreur lors de la requ�te API :', error);
                        alert("No reservation already exist for this client ");
                        $scope.i = true;
                    });

            

            
            // Appel � la fonction pour r�cup�rer les num�ros de t�l�phone r�serv�s
           // $scope.reserved=$scope.checkReservedNumbers(client);

           
        };




       /* $scope.openUnreservationModal = function (client) {

            console.log('client dans openUnreservationModal :', client);

            $http.get('/api/reservations/reservedForClient', { params: { ClientName: client.Name } })
                .then(function (response) {
                    console.log('client2:', client);

                    // La r�ponse contient les num�ros de t�l�phone r�serv�s
                    $scope.reservedPhoneNumbers = response.data;
                    console.log('le check:', response);
                    console.log('reservednumber:', $scope.reservedPhoneNumbers)
                })
                .catch(function (error) {
                    // G�rez les erreurs ici
                    console.error('Erreur lors de la requ�te API :', error);
                });


            var modalInstance = $uibModal.open({
                template: `
                           <div class="modal-header">
                                    <h3 class="modal-title">Unreservation</h3>
                                    <button type="button" class="close" ng-click="close()" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                           </div>
                           <div class="modal-body">
                                   <p>Select a number for unreservation :</p>
                                    <phone-selector selected-phone="selectedPhoneNumber" phones="reservedPhoneNumbers"></phone-selector>
                                    <p>{{selectedPhoneNumber}}</p>
                           </div>
                           <div class="modal-footer">
                                  <button class="btn btn-default" ng-click="close()">cancel</button>
                                  <button class="btn btn-primary" ng-click="ok()">save</button>
                           </div>        `,
                controller: 'UnreservationModalController',
                resolve: {

                    reservedPhoneNumbers: function () {
                        return $scope.reservedPhoneNumbers; // Assurez-vous que la variable est correctement d�finie
                    },
                    client: function () {
                        return client;
                    }
                }
            });

            modalInstance.result.then(function (result) {
                console.log('Unreservation instance result:', result);

                if (result !== undefined) {
                    // Ici, vous pouvez mettre � jour ou annuler la r�servation en utilisant le r�sultat.
                    // Par exemple, $scope.updateReservation(result) ou $scope.cancelReservation(result)
                }
            });
        };*/

      /*  $scope.openUnreservationModal = function (client) {
            console.log('client dans openUnreservationModal :', client);

            // Appel � l'API pour r�cup�rer les num�ros de t�l�phone r�serv�s
            $http.get('/api/reservations/reservedForClient', { params: { ClientName: client.Name } })
                .then(function (response) {
                    console.log('client2:', client);

                    // La r�ponse contient les num�ros de t�l�phone r�serv�s
                    $scope.reservedPhoneNumbers = response.data;
                    console.log('reservednumbers:', $scope.reservedPhoneNumbers)

                    // Ouvrir la modal apr�s avoir r�cup�r� les num�ros de t�l�phone
                    openModal();
                })
                .catch(function (error) {
                    // G�rez les erreurs ici
                    console.error('Erreur lors de la requ�te API :', error);
                });

            function openModal() {
                var modalInstance = $uibModal.open({
                    template: `
               <div class="modal-header">
                    <h3 class="modal-title">Unreservation</h3>
                    <button type="button" class="close" ng-click="close()" aria-label="Close"><span aria-hidden="true">&times;</span></button>
               </div>
               <div class="modal-body">
                   <p>Select a number for unreservation :</p>
                   <!-- Utilisez un ng-options pour cr�er une liste d�roulante de num�ros de t�l�phone -->
                   <select ng-model="selectedPhoneNumber" ng-options="phoneNumber for phoneNumber in reservedPhoneNumbers"></select>
               </div>
               <div class="modal-footer">
                    <button class="btn btn-default" ng-click="close()">cancel</button>
                    <button class="btn btn-primary" ng-click="ok()">save</button>
               </div>`,
                    controller: 'UnreservationModalController',
                    resolve: {
                        reservedPhoneNumbers: function () {
                            return $scope.reservedPhoneNumbers; // Assurez-vous que la variable est correctement d�finie
                        },
                        client: function () {
                            return client;
                        }
                    }
                });

                modalInstance.result.then(function (result) {
                    console.log('Unreservation instance result:', result);

                    if (result !== undefined) {
                        // Ici, vous pouvez mettre � jour ou annuler la r�servation en utilisant le r�sultat.
                        // Par exemple, $scope.updateReservation(result) ou $scope.cancelReservation(result)
                    }
                });
            }
        };*/


       
    }])
  



    .controller('ModalController1', ['$scope', '$uibModalInstance', 'isEdit', 'client', function ($scope, $uibModalInstance, isEdit, client) {

        console.log('received client:', client);

        $scope.isEdit = isEdit;
        $scope.input_name = client ? client.Name : '';
        $scope.selectedType = client ? client.Type : '';
      // $scope.inputDatetime = new Date(client.Birthdate) ;
       $scope.inputDatetime = client && client.Birthdate ? new Date(client.Birthdate) : null;

       // $scope.client = client ? angular.copy(client) : {};
       // console.log('copied one:', client);
//       
        
        $scope.saveMyModal = function () {

          
          //  var inputDateTime = new Date();
            // Pour extraire la date seulement (ignorer l'heure)
         //var dateOnly = new Date(inputDateTime.getFullYear(), inputDateTime.getMonth(), inputDateTime.getDate());
          
            
            var newClient = {
              
                Name: $scope.input_name,
                Type: $scope.selectedType,
                Birthdate: $scope.inputDatetime
               // Birthdate: $scope.selectedType === 'Individual' ? dateOnly : null

               // Birthdate: dateOnly
                //Birthdate: $scope.inputDatetime
               // Birthdate: Type === 'Organization' ? null : inputDatetime

            };
            if (!newClient || !newClient.Name || !newClient.Type || (!newClient.Birthdate && newClient.Type === 'Individual')) {
                alert("Please fill in all fields for the new client!");
                return; // Sortir de la fonction si des champs sont vides
            }
           /* var clientExists = $scope.clients && $scope.clients.some(function (client) {
                return client.Name === newClient.Name && client.Type === newClient.Type && client.Birthdate === newClient.Birthdate;
            });

            if (clientExists) {
                alert("Client with these specifications already exists!");
                return;
            }*/

           
            if (newClient.Birthdate) {
                var birthdate = new Date(newClient.Birthdate);
                var today = new Date();
                var age = today.getFullYear() - birthdate.getFullYear();
               /* if (!$scope.input_name) {
                    alert("Please enter the client name!");
                }
               else {
                    if ($scope.input_name && !$scope.selectedType) {
                        alert("Please enter the client type!");
                    }
                    else {
                        if ($scope.input_name && $scope.selectedType === 'individual' && !$scope.inputDatetime) {
                            alert("Please enter the client birthdate!")
                        }
                    }
                }*/
                if (age < 18) {
                    alert("Please note that clients must be 18 years of age or older to be added! Thank you for your understanding.")
                    return;
                };
            };
           // console.log('extracted 3:', extractedDate);

            console.log("my newClient in save=", newClient.Name, newClient.Type, newClient.Birthdate)
            $uibModalInstance.close(newClient);
        };
        
        $scope.closeModal = function () {
            $uibModalInstance.dismiss('cancel');
        };
        
    
    }])


    .controller('ReservationModalController', ['$scope', '$uibModalInstance', 'availablePhoneNumbers', 'client', function ($scope, $uibModalInstance, availablePhoneNumbers, client) {
        $scope.availablePhoneNumbers = availablePhoneNumbers; // Utilisez 'availablePhoneNumbers' ici
        $scope.selectedPhoneNumber = '';
        console.log('client in reserve:', client);
        $scope.ok = function () {
           if ($scope.selectedPhoneNumber) {
          //  if (client && client.Name && $scope.selectedPhoneNumber) {

                var newReserve = {

                    ClientName:client.Name,
                    PhoneNumber:$scope.selectedPhoneNumber,
                    BED:new Date(),
                    EED:null

                }
                console.log('newReserve', newReserve);
               $uibModalInstance.close(newReserve);
            } else {
                // Vous pouvez ajouter une validation ici si n�cessaire
            }
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
       /* $scope.checkReservation(client);

        $scope.checkReservation = function (client) {

            $http.post('/api/reservations/check', { ClientName: client.Name })
                .then(function (response) {
                    var hasReservation = response.data;

                    if (hasReservation) {
                        console.log('Le client a des r�servations.');
                    } else {
                        console.log('Le client n\'a pas de r�servations.');
                    }
                })
                .catch(function (error) {
                    console.error('Erreur lors de la requ�te API :', error);
                });
        };*/

    }])
   
.controller('UnreservationModalController', ['$scope', '$uibModalInstance', 'client', 'reservedPhoneNumbers', function ($scope, $uibModalInstance, client, reservedPhoneNumbers) {
    $scope.reservedPhoneNumbers = reservedPhoneNumbers; // Utilisez 'availablePhoneNumbers' ici
    $scope.client = client; // Donn�es du client pass�es depuis la fonction openUnreservationModal

    // D�finir une variable pour stocker la s�lection de l'utilisateur
    $scope.selectedNumber = null;
    console.log('client in controller', client);
    console.log('reserved in controller', $scope.reservedPhoneNumbers);
    console.log('selected in controller', $scope.selectedNumber);
    // Fonction pour fermer la modal sans effectuer d'annulation
    $scope.close = function () {
        $uibModalInstance.dismiss('cancel'); // Utilisez 'cancel' ou une autre valeur pour indiquer la fermeture de la modal sans r�sultat.
    };

    // Fonction pour g�rer le bouton "save" et transmettre la s�lection de l'utilisateur
    $scope.ok = function (selectedNumber) {
        
        var updatedReserve = {

            ClientName: client.Name,
            PhoneNumber: selectedNumber,
            EED: new Date()

        }
        console.log('updatedReserve in controller:', updatedReserve);
        $uibModalInstance.close(updatedReserve);
    } 

}]);
