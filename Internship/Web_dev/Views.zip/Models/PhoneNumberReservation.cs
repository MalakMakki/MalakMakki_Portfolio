﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class PhoneNumberReservation
    {
        public int Id { get; set; }

        public string ClientName { get; set; }

        public string PhoneNumber { get; set; }

        public DateTime BED { get; set; }

        public Nullable<DateTime> EED { get; set; }
    }
}