﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace WebApplication5.Models
{
    public class Phone
    {
        public int Id { get; set; }
        public string Number { get; set; }
        public int DeviceId { get; set; }
        //public string DeviceName { get; set; }


    }

    public class PhoneWithName
    {
        public int Id { get; set; }
        public string Number { get; set; }
        public string DeviceName { get; set; }

    }
}