angular.module('myApp5', ['ui.bootstrap'])

    .directive('deviceSelector', function () {
        return {
            restrict: 'E',
            template: `

        <select name="Device" id="Device" ng-model="selectedDevice" style="padding:8px;" >
            <option value=""></option>
            <option ng-repeat="device in devices" value="{{device.Name}}">{{device.Name}}</option>
        </select>`,
            scope: {
                selectedDevice: '=',
                devices: '=' // Assurez-vous que vous avez une liaison pour les dispositifs
            },
            controller: function ($scope) {
                // La logique de r�cup�ration des donn�es du dispositif va ici
                // Par exemple, vous pouvez avoir une fonction getData
                $scope.getData = function () {
                    var selectedDevice = $scope.selectedDevice;
                    console.log('Dispositif s�lectionn� :', selectedDevice);
                }
            }
        };
    })


    .controller('MainController5', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {


        $scope.devices = [];
        $scope.selectedDevice = ''; // Initialisez selectedDevice en tant que cha�ne vide pour stocker le nom du dispositif
        $scope.selectedDeviceId = ''; 

        // Fonction pour charger les donn�es des dispositifs depuis l'API
        function loadDevices() {
            $http.get('/api/devices')
                .then(function (response) {
                    $scope.devices = response.data;
                })
                .catch(function (error) {
                    console.log('Erreur lors de la r�cup�ration des dispositifs :', error);
                });
        }

        // Charger les donn�es des dispositifs au d�marrage du contr�leur
        loadDevices();
        $http.get('/api/reserves/report')
            .then(function (response) {
                $scope.results = response.data;
            })
            .catch(function (error) {
                console.error('Error:', error);
            });

        

       /* $scope.showReserved = true;
        $scope.showUnreserved = true;
        $scope.searchDevNum = function () {
            console.log('Selected Device: ' + $scope.selectedDevice);
            console.log('reservation: ' + $scope.showReserved);
             // $scope.showReserved = ($scope.selectedStatus === '' || $scope.selectedStatus === 'Reserved');
            //  $scope.showUnreserved = ($scope.selectedStatus === '' || $scope.selectedStatus === 'Unreserved');


            $http.get('/api/reserves/filter', { params: { deviceName: $scope.selectedDevice } } )
                .then(function (response) {
                    console.log('dans search function apres api, response=', response);
                    $scope.results = response.data;
                })
                .catch(function (error) {
                    console.error('Error:', error);
                });
           
            $scope.showReserved = ($scope.selectedStatus === '' || $scope.selectedStatus === 'Reserved');
            $scope.showUnreserved = ($scope.selectedStatus === '' || $scope.selectedStatus === 'Unreserved');

        };*/

        $scope.showReserved = true;
        $scope.showUnreserved = true;

        $scope.searchDevNum = function () {
            console.log('Selected Device: ' + $scope.selectedDevice);
            console.log('Reservation: ' + $scope.selectedStatus);

            $http.get('/api/reserves/filter', { params: { deviceName: $scope.selectedDevice } })
                .then(function (response) {
                    console.log('Dans search function apr�s API, response=', response);
                    $scope.results = response.data;
                })
                .catch(function (error) {
                    console.error('Error:', error);
                });

            // Ajoutez une condition pour v�rifier si selectedStatus est vide ou nul
            if (!$scope.selectedStatus) {
                $scope.showReserved = true;
                $scope.showUnreserved = true;
            } else {
                $scope.showReserved = ($scope.selectedStatus === 'Reserved');
                $scope.showUnreserved = ($scope.selectedStatus === 'Unreserved');
            }
        };

        
    }]);