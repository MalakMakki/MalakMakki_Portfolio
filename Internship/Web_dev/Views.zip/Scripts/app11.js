
angular.module('myApp6', ['ui.bootstrap'])
    .controller('LoginController', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {

        $scope.username = '';
        $scope.password = '';
        $scope.signUp = function () {
            console.log('je suis dans signUp function');
            console.log('username:', $scope.username);
            console.log('password:', $scope.password);
        }
      /*  $scope.user = {
            Username: 'Malak',
            Password: '123'
        };

        console.log('userData dans signup avant api:', user);



        $http.post('/api/login/add', user)
            .then(function (response) {
                console.log(response);

                // Redirigez l'utilisateur vers la page "Home/HomePage" apr�s l'ajout r�ussi.
                window.location.href = '/Home/HomePage';
            })
            .catch(function (error) {
                console.log('Error adding user:', error);
            });*/


    }]);




















/*angular.module('myApp6').factory('authService', ['$http', function ($http) {
    var authService = {};

    authService.login = function (username, password) {
        return $http.post('/api/login', { username: username, password: password });
    };

    authService.login = function (userData) {
        return $http.post('/api/signup', userData);
    };

    return authService;
}]);


angular.module('myApp6').controller('AuthController', ['$scope', 'authService', function ($scope, authService) {
    $scope.username = '';
    $scope.password = '';

    $scope.login = function () {
        authService.login($scope.username, $scope.password)
            .then(function (response) {
                // G�rer la r�ussite de la connexion ici, par exemple, rediriger l'utilisateur vers une autre page.
            })
            .catch(function (error) {
                // G�rer les erreurs de connexion ici, par exemple, afficher un message d'erreur � l'utilisateur.
            });
    };

    $scope.signUp = function () {
        var userData = {
            username: $scope.username, // R�cup�rez le nom d'utilisateur � partir de votre formulaire
            password: $scope.password // R�cup�rez le mot de passe � partir de votre formulaire
        };
        console.log('userData dans signup avant api:', userData);
        authService.signUp(userData)
            .then(function (response) {
                console.log('Inscription r�ussie:', response.data.message);
            })
            .catch(function (error) {
                console.error('Erreur d\'inscription:', error.data.message);
            });
    };
}]);
*/