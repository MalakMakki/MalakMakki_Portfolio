﻿angular.module('myApp', ['ui.bootstrap','sharedApp'])
    .factory('AuthService', ['$http', function ($http) {
        var isAuthenticated = false; // Variable pour suivre l'état de l'authentification

        // Fonction pour effectuer l'authentification
        function login(username, password) {
            // Ici, vous devrez envoyer une requête HTTP au serveur pour vérifier les informations d'authentification
            // Si les informations sont correctes, mettez isAuthenticated à true
            // Exemple de requête HTTP (à adapter à votre backend) :

            return $http.post('/api/login', { username: username, password: password })
                .then(function (response) {
                    isAuthenticated = true; // Authentification réussie, définissez isAuthenticated à true
                    return response.data; // Vous pouvez renvoyer des données utilisateur ou d'autres informations si nécessaire
                })
                .catch(function (error) {
                    isAuthenticated = false; // Authentification échouée, définissez isAuthenticated à false
                    throw error; // Propagez l'erreur pour la gestion des erreurs côté client
                });

        }

        // Fonction pour déconnecter l'utilisateur
        function logout() {
            // Ici, vous devrez mettre isAuthenticated à false et effectuer d'autres opérations de déconnexion si nécessaire
            isAuthenticated = false;
            // Ajoutez ici le code de déconnexion personnalisé, si nécessaire
        }

        // Fonction pour vérifier si l'utilisateur est authentifié
        function checkAuth() {
            // Ici, vous pouvez vérifier l'état de isAuthenticated pour déterminer si l'utilisateur est authentifié
            return isAuthenticated;
        }

        // Exposer les fonctions et les propriétés nécessaires
        return {
            login: login,
            logout: logout,
            isAuthenticated: checkAuth
        };
    }]);

    .controller('MainController', ['$scope', '$http', '$uibModal', 'AuthService', function ($scope, $http, $uibModal, AuthService) {
        $scope.isAuthenticated = AuthService.isAuthenticated;


        $scope.devices = []; // Initialisez le tableau pour stocker les dispositifs
        
        // Chargez les dispositifs à partir de l'API
        $http.get('/api/devices')
            .then(function (response) {
                $scope.devices = response.data; // Stockez les dispositifs récupérés dans le tableau
            })
            .catch(function (error) {
                console.log('Erreur lors du chargement des dispositifs :', error);
            });
            


        $scope.Search = function () {
            $http.get('/api/devices/filter', { params: { filter: $scope.Input } })
                .then(function (response) {
                    $scope.devices = response.data;
                })
                .catch(function (error) {
                    console.log('Error loading filtered devices:', error);
                });
        };




        function addDevice(deviceName) {

         /*   if (!deviceName) {
                alert("Please enter a new device name!");
                return; // Sortir de la fonction si le champ est vide
            }*/

            var nameExists = $scope.devices.some(function (d) {
                return d.Name === deviceName;
            });

            if (nameExists) {
                alert("Device with this name already exists!");
                return; 
            }
            var newDevice = { Name: deviceName };
           
                $http.post('/api/devices', newDevice)
                    .then(function (response) {
                        $scope.devices.push(response.data);
                        return $http.get('/api/devices');
                    })
                    .then(function (response) {
                        $scope.devices = response.data;
                        alert("Device added successfully!");
                    })
                    .catch(function (error) {
                        console.log('Error adding device:', error);


                    });

                  
            
        }

        /*function updateDevice(device, newName) {
            if (!newName) {
                alert("Please enter a new device name!");
                return; // Sortir de la fonction si le champ est vide
            }

            // Vérifier si le nouveau nom existe déjà
            var nameExists = $scope.devices.some(function (d) {
                return d.Name === newName;
            });

            if (nameExists) {
                alert("Device with this name already exists!");
                return; // Sortir de la fonction si le nom existe déjà
            }
            var updatedDevice = { Id: device.Id, Name: newName };

            $http.put('/api/devices/' + device.Id, updatedDevice)
                .then(function (response) {
                    // Mettre à jour le nom du device avec la nouvelle valeur
                     device.Name = response.data.Name;
                   // alert("Device edited successfully!");
                    $scope.devices = response.data;
                    alert("Device edited successfully!");
                })
                .catch(function (error) {
                    console.log('Error updating device:', error);
                });
        }
        */
        function updateDevice(device, newName) {

           /* if (!newName) {
                alert("Please enter a new device name!");
                return; // Sortir de la fonction si le champ est vide
            }*/

            // Vérifier si le nouveau nom existe déjà
            var nameExists = $scope.devices.some(function (d) {
                return d.Name === newName;
            });

            if (nameExists) {
                alert("Device with this name already exists!");
                return; // Sortir de la fonction si le nom existe déjà
            }
            var updatedDevice = { Id: device.Id, Name: newName };

            $http.put('/api/devices/' + device.Id, updatedDevice)
                .then(function (response) {
                    device.Name = response.data.Name;
                    
                    console.log("device edited successfully!");
                    alert("Device edited successfully!")

                    
                    $http.get('/api/devices')
                        .then(function (response) {
                            $scope.devices = response.data;

                        })
                        .catch(function (error) {
                            console.log('Erreur lors du chargement des dispositifs :', error);
                        });
                })
              // alert("Device edited successfully2!")

                .catch(function (error) {
                    console.log('Error updating device:', error);
                });
        }
        $scope.saveMyModal = function () {
            //$scope.formSubmitted = true; 
            if ($scope.input) {

                var newValue = $scope.input;
                $uibModalInstance.close(newValue);
            }

        };


        

        $scope.openModal = function (isEdit, device) {
            var modalInstance = $uibModal.open({
                templateUrl: 'myModalContent.html',
                controller: 'ModalInstanceController',
                resolve: {
                    isEdit: function () {
                        return isEdit;
                    },
                    device: function () {
                        return device;
                    }
                }
            });

            modalInstance.result.then(function (result) {
                console.log("result:", result);
                if (result !== '') {
                    if (isEdit) {
                        // Update the existing device
                        updateDevice(device, result);
                    } else {
                        // Add a new device
                        addDevice(result);
                    }
                }
                else {
                    console.log("Please enter a new device name")
                    alert("Please enter a new device name!");

                }
            });
        };

    }])

    .controller('ModalInstanceController', ['$scope', '$uibModalInstance', 'isEdit', 'device', function ($scope, $uibModalInstance, isEdit, device) {
        console.log('received device:', device);
        $scope.isEdit = isEdit;
        $scope.input = device ? device.Name : '';
       // $scope.formSubmitted = true; 

        $scope.saveMyModal = function () {
            //$scope.formSubmitted = true; 
           

            var newValue = $scope.input;
            if (!newValue) {
                alert("Please enter a new device name!");
                return; // Sortir de la fonction si le champ est vide
            }

            // Vérifier si le nouveau nom existe déjà
           
                $uibModalInstance.close(newValue);
            
           
        };

        $scope.closeModal = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);

