
angular.module('myApp', ['ui.bootstrap'])
    .controller('MainController', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {
        $scope.devices = []; // Initialisez le tableau pour stocker les dispositifs

        // Chargez les dispositifs � partir de l'API
        $http.get('/api/devices')
            .then(function (response) {
                $scope.devices = response.data; // Stockez les dispositifs r�cup�r�s dans le tableau
            })
            .catch(function (error) {
                console.log('Erreur lors du chargement des dispositifs :', error);
            });

    

          $scope.Search = function () {
              $http.get('/api/devices/filter', { params: { search: $scope.Input } })
                .then(function (response) {
                    $scope.devices = response.data;
                })
                .catch(function (error) {
                    console.log('Error loading filtered devices:', error);
                });
           
        };


      

        function addDevice(deviceName) {
            var newDevice = { Name: deviceName };

            $http.post('/api/devices', newDevice)
                .then(function (response) {
                    $scope.devices.push(response.data);
                })
                .catch(function (error) {
                    console.log('Error adding device:', error);
                });
        }

        function updateDevice(device, newName) {
            var updatedDevice = { Id: device.Id, Name: newName };

            $http.put('/api/devices/' + device.Id, updatedDevice)
                .then(function (response) {
                    device.Name = response.data.Name;
                })
                .catch(function (error) {
                    console.log('Error updating device:', error);
                });
        }



        $scope.openModal = function (isEdit, device) {
            var modalInstance = $uibModal.open({
                templateUrl: 'myModalContent.html',
                controller: 'ModalInstanceController',
                resolve: {
                    isEdit: function () {
                        return isEdit;
                    },
                    device: function () {
                        return device;
                    }
                }
            });

            modalInstance.result.then(function (result) {
                if (result !== undefined) {
                    if (isEdit) {
                        // Update the existing device
                        updateDevice(device, result);
                    } else {
                        // Add a new device
                        addDevice(result);
                    }
                }
            });
        };

    }])

    .controller('ModalInstanceController', ['$scope', '$uibModalInstance', 'isEdit', 'device', function ($scope, $uibModalInstance, isEdit, device) {
        $scope.isEdit = isEdit;
        $scope.input = device ? device.Name : '';

        $scope.saveMyModal = function () {
            var newValue = $scope.input;
            $uibModalInstance.close(newValue);
        };

        $scope.closeModal = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);

