angular.module('myApp3', ['ui.bootstrap'])

    .directive('typeSelector', function () {
        return {
            restrict: 'E',
            template: `
           
           <select name="Type" id="Type" style="padding: 8px;" ng-model="selectedType">
                      <option value=""></option>
                      <option value="Individual">Individual</option>
                      <option value="Organization">Organization</option>
             </select>  `,
            scope: {
                selectedType: '=' 
            },
            controller: function ($scope) {
               
                $scope.getData = function () {
                    var selectedType = $scope.selectedType;
                    console.log('Type s�lectionn� :', selectedType);


                }
            }
        };
    })

    .directive('phoneSelector', function () {
        return {
            restrict: 'E',
            template: `
           
           <select name="Phone" id="Phone" style="padding: 8px;" ng-model="selectedPhone">
                      <option value=""></option>
                      <option ng-repeat="phone in phones" value="{{phone.Id}}">{{phone.Number}}</option>

             </select>  `,
            scope: {
                selectedPhone: '=',// Liaison bidirectionnelle pour la valeur s�lectionn�e
                phones:'='
            },
            controller: function ($scope) {
               
                $scope.getData = function () {
                    var selectedphone = $scope.selectedPhone;
                    console.log('Phone s�lectionn� :', selectedphone);


                }
            }
        };
    })

    .controller('MainController3', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {
        console.log('hello! you are in controller');
        $scope.phones = [];
        $scope.devices = [];
        $scope.reservations = [];
        // Fonction pour charger les donn�es des dispositifs depuis l'API
        function loadDevices() {
            $http.get('/api/devices')
                .then(function (response) {
                    $scope.devices = response.data;
                })
                .catch(function (error) {
                    console.log('Erreur lors de la r�cup�ration des dispositifs :', error);
                });
        }

        // Charger les donn�es des dispositifs au d�marrage du contr�leur
        function loadPhones() {

            $http.get('/api/phones')
                .then(function (response) {
                    $scope.phones = response.data;
                })
                .catch(function (error) {
                    console.log('Erreur lors du chargement des t�l�phones :', error);
                });
        }

        loadDevices();
        loadPhones();


        $http.get('/api/reservations')
            .then(function (response) {
                $scope.reservations = response.data;
                console.log($scope.reservations);
            })
            .catch(function (error) {
                console.log('Erreur lors du chargement des r�s�rvations :', error);
            });



        /*$scope.filterReservations = function () {
            // R�cup�rez les valeurs s�lectionn�es depuis les s�lecteurs
            //var selectedType = $scope.selectedType;
            //var selectedPhoneId = $scope.phoneSelection; // Utilisez la valeur s�lectionn�e depuis le s�lecteur de t�l�phone

            // Appel de la m�thode de filtrage API
            $http.get('/api/reservations/filter', {
                params: {
                    //type: selectedType,
                    phoneNumberId: $scope.phoneSelection

                }
            })
                .then(function (response) {
                    $scope.reservations = response.data;
                    
                })
                .catch(function (error) {
                    console.log('Erreur lors du filtrage des r�servations :', error);
                });
        };*/

        $scope.filterReservations = function () {

            if ($scope.selectedPhone) {
                var phoneNumber = $scope.selectedPhone;
                console.log($scope.selectedPhone);
            }// Num�ro de t�l�phone s�lectionn�

            if ($scope.selectedType) {
                var type = $scope.selectedType === 'Individual' ? 1 : 2; // Type s�lectionn� (1 pour Individual, 2 pour Organization)
            }
            // Appel de l'API avec les param�tres
            $http.get('/api/reservations/filter', {
                params: { phoneNumber: phoneNumber, type: type }
            })
                .then(function (response) {
                    // Traitement de la r�ponse de l'API ici (par exemple, mettre � jour la liste des r�servations)
                    $scope.reservations = response.data;
                    console.log(response);
                })
                .catch(function (error) {
                    console.log('Erreur lors du filtrage des r�servations :', error);
                });
        };
       
       
    }])
