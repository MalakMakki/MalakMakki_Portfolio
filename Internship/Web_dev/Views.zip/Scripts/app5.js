angular.module('myApp2', ['ui.bootstrap'])

    .controller('MainController2', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {
        $scope.phones = [];
        $scope.devices = [];

        // R�cup�rer la liste des dispositifs depuis la base de donn�es
        ////////////////////////////////////////////////////////////////////////////////
        $http.get('/api/devices')
            .then(function (response) {
                $scope.devices = response.data;

                // Une fois que les donn�es sont charg�es, ouvrez le modal
                console.log('avant openModal', $scope.devices)

                $scope.openModal = function (isEdit, phone) {
                    var modalInstance = $uibModal.open({
                        templateUrl: 'myModalContent2.html',
                        controller: 'ModalController2',
                        resolve: {
                            isEdit: function () {
                                return isEdit;
                            },
                            phone: function () {
                                return phone;
                            },
                            devices: function () {
                                return $scope.devices;
                            }
                        }
                    });

                    modalInstance.result.then(function (result) {
                        if (result !== undefined) {
                            if (isEdit) {
                                $scope.updatePhone(phone, result);
                            } else {
                                $scope.addPhone(result);
                            }
                        }
                    });
                };
            })
            .catch(function (error) {
                console.log('Erreur lors de la r�cup�ration des dispositifs :', error);
            });

        ////////////////////////////////////////////////////////////////////////////////
       /* $http.get('/api/devices')
            .then(function (response) {
                $scope.devices = response.data;
            })
            .catch(function (error) {
                console.log('Erreur lors de la r�cup�ration des dispositifs :', error);
            });*/

        // R�cup�rer la liste des t�l�phones depuis la base de donn�es
        $http.get('/api/phones')
            .then(function (response) {
                $scope.phones = response.data;
            })
            .catch(function (error) {
                console.log('Erreur lors du chargement des t�l�phones :', error);
            });

        $scope.searchPhones = function () {
            // Appel de l'API avec les param�tres de recherche
            $http.get('/api/phones/search', { params: { phoneNumber: $scope.searchPhone, deviceId: $scope.deviceSelection } })
                .then(function (response) {
                    $scope.phones = response.data;
                    if ($scope.phones.length === 0) {
                        $scope.noResultsFound = true;
                    } else {
                        $scope.noResultsFound = false;
                    }
                })
                .catch(function (error) {
                    console.log('Erreur lors du chargement des clients :', error);
                });
        };
        console.log('apres openModal',$scope.devices)
       /* $scope.openModal = function (isEdit, phone) {
            var modalInstance = $uibModal.open({
                templateUrl: 'myModalContent2.html',
                controller: 'ModalController2',
                resolve: {
                    isEdit: function () {
                        return isEdit;
                    },
                    phone: function () {
                        return phone;
                    },
                    devices: function () {
                        return $scope.devices;
                    }
                }
            });

            modalInstance.result.then(function (result) {
                if (result !== undefined) {
                    if (isEdit) {
                        $scope.updatePhone(phone, result);
                    } else {
                        $scope.addPhone(result);
                    }
                }
            });
        };*/

        $scope.updatePhone = function (phone, newPhone) {
            // Mettez � jour le t�l�phone dans la base de donn�es et mettez � jour $scope.phones
            // Impl�mentez cette fonction en fonction de votre structure de base de donn�es et de votre API

        };

        $scope.addPhone = function (newPhone) {
            // Ajoutez le t�l�phone � la base de donn�es et mettez � jour $scope.phones
            // Impl�mentez cette fonction en fonction de votre structure de base de donn�es et de votre API
        };
    }])

    .controller('ModalController2', ['$scope', '$uibModalInstance', 'isEdit', 'phone', 'devices', function ($scope, $uibModalInstance, isEdit, phone, devices) {
        $scope.isEdit = isEdit;
        $scope.inputPhoneNumber = phone ? phone.Number : '';
        $scope.devices = devices; // Fournissez la liste des dispositifs au modal
        $scope.inputDevice = phone ? getDeviceNameById(phone.DeviceId) : '';

        function getDeviceNameById(deviceId) {
            var deviceName = '';

            for (var i = 0; i < $scope.devices.length; i++) {
                if ($scope.devices[i].Id === deviceId) {
                    deviceName = $scope.devices[i].Name;
                    break;
                }
            }

            return deviceName;
        }







        $scope.savePhoneModal = function () {
            // Votre logique pour sauvegarder les modifications du t�l�phone ici
            // Utilisez $uibModalInstance.close() pour fermer le modal avec les donn�es modifi�es
            //////////////////////////////////////
            console.log(inputDevice);
            var selectedDeviceId = null;
            for (var i = 0; i < devices.length; i++) {
                if (devices[i].Name === $scope.inputDevice) {
                    selectedDeviceId = devices[i].Id;
                    break; // Sortir de la boucle d�s qu'une correspondance est trouv�e
                }
            }

            // Cr�ation de l'objet newPhone avec l'ID du dispositif correspondant
            var newPhone = {
                Id: phone.Id, // Assuming phone has an Id property
                Number: $scope.inputPhoneNumber,
                DeviceId: selectedDeviceId // Utilisation de l'ID trouv�
            };
            console.log(selectedDeviceId);
            $uibModalInstance.close(newPhone);
            //////////////////////////////////////
        };

        $scope.closePhoneModal = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);
