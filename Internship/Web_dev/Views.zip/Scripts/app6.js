//angular.module('myApp2', ['ui.bootstrap','sharedApp'])

angular.module('myApp2', ['ui.bootstrap'])


/*.directive('deviceSelector', function () {
    return {
        restrict: 'E', // Restrict usage to element tags
        template: `
            <select name="Device" id="Device" style="padding: 8px;" ng-model="inputDevice">
                <option value=""></option>
                <option ng-repeat="device in devices" value="{{device.Id}}">{{device.Name}}</option>
            </select>
           
        `,        scope: {
            devices: '=', // Two-way binding for the devices array
            selectedDevice: '=' // Two-way binding for the selected device
        }
    };
})*/

  /*  .directive('deviceSelector', function () {
        return {
            restrict: 'E',
            template: `
             <select name="Device" id="Device" style="padding: 8px;" ng-model="selectedDevice">
                <option value=""></option>
                <option ng-repeat="device in devices" value="{{device.Id}}">{{device.Name}}</option>
            </select>  `,
            scope: {
                selectedDevice: '=' ,// Liaison bidirectionnelle pour la valeur s�lectionn�e
                devices: '='
            },
            controller: function ($scope) {
                // La logique de r�cup�ration des donn�es du type va ici
                // Par exemple, vous pouvez avoir une fonction getData
                $scope.getData = function () {
                    var selectedDevice = $scope.selectedDevice;
                    console.log('Type s�lectionn� :', selectedDevice);


                }
            }
        };
    })*/
    .directive('deviceSelector', function () {
        return {
            restrict: 'E',
            template: `

        <select name="Device" id="Device" ng-model="selectedDevice" style="padding: 10px; width: 200px;">
            <option value=""></option>
            <option ng-repeat="device in devices" value="{{device.Id}}">{{device.Name}}</option>
        </select>`,
            scope: {
                selectedDevice: '=',
                devices: '=' // Assurez-vous que vous avez une liaison pour les dispositifs
            },
            controller: function ($scope) {
                // La logique de r�cup�ration des donn�es du dispositif va ici
                // Par exemple, vous pouvez avoir une fonction getData
                $scope.getData = function () {
                    var selectedDevice = $scope.selectedDevice;
                    console.log('Dispositif s�lectionn� :', selectedDevice);
                }
            }
        };
    })



    .controller('MainController2', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {
        //$scope.isAuthenticated = AuthService.isAuthenticated;

        $scope.phones = [];
        $scope.devices = [];
        $scope.selectedDevice = {
            Id: 0,
            Name: ""
        };

        // Fonction pour charger les donn�es des dispositifs depuis l'API
        function loadDevices() {
            $http.get('/api/devices')
                .then(function (response) {
                    $scope.devices = response.data;
                })
                .catch(function (error) {
                    console.log('Erreur lors de la r�cup�ration des dispositifs :', error);
                });
        }

        // Charger les donn�es des dispositifs au d�marrage du contr�leur
        loadDevices();
        $http.get('/api/phones')
            .then(function (response) {
                $scope.phones = response.data;
            })
            .catch(function (error) {
                console.log('Erreur lors du chargement des t�l�phones :', error);
            });

        $scope.searchPhones = function () {
            // Appel de l'API avec les param�tres de recherche
            $http.get('/api/phones/search', { params: { phoneNumber: $scope.searchPhone, deviceId: $scope.deviceSelection } })
                .then(function (response) {
                    $scope.phones = response.data;
                    if ($scope.phones.length === 0) {
                        $scope.noResultsFound = true;
                    } else {
                        $scope.noResultsFound = false;
                    }
                })
                .catch(function (error) {
                    console.log('Erreur lors du chargement des clients :', error);
                });
        };
        // Fonction pour ouvrir le modal

        $scope.updatePhone = function (phone, newPhone) {
            if (!phone || !phone.Id) {
                console.error('phone.Id est manquant ou non d�fini.');
                return;
            }
            var phoneExists = $scope.phones.some(function (p) {
                return p.Number === newPhone.Number;
            });

            if (phoneExists) {
                alert("Phone Number already exists!");
                return; // Sortir de la fonction si le nom existe d�j�
            }
            console.log('phoneId:', phone.Id)
            var data = {
                Id:phone.Id,
                Number: newPhone.Number,
                DeviceId: newPhone.DeviceId
            };
            console.log('data:', data)

            $http.put('/api/phones/update', data)
                .then(function (response) {
                    // La mise � jour a r�ussi
                    console.log(response.data);
                    // Mettez � jour votre liste de t�l�phones si n�cessaire
                    alert("Phone edited Successfully!");
                    $http.get('/api/phones')
                        .then(function (response) {
                            $scope.phones = response.data;
                        })
                        .catch(function (error) {
                            console.log('Erreur lors du chargement des t�l�phones :', error);
                        });
                })
                .catch(function (error) {
                    console.error('Erreur lors de la mise � jour du t�l�phone :', error);
                });
        };



        $scope.addPhone = function (newPhone) {
            var phoneExists = $scope.phones.some(function (p) {
                return p.Number === newPhone.Number;
            });

            if (phoneExists) {
                alert("Phone Number already exists!");
                return; // Sortir de la fonction si le nom existe d�j�
            }
            // Ajoutez le t�l�phone � la base de donn�es et mettez � jour $scope.phones
            // Impl�mentez cette fonction en fonction de votre structure de base de donn�es et de votre API
            console.log('dans add function au debut:', newPhone);
            $http.post('/api/phones/add', newPhone)
                .then(function (response) {
                    console.log(response);
                    alert("Phone Added Successfully!");

                })
           
               .catch(function (error) {
                   console.log('Error adding device:', error);
                   alert("Phone Added Successfully!");

                   $http.get('/api/phones')
                       .then(function (response) {
                           $scope.phones = response.data; // Stockez les dispositifs r�cup�r�s dans le tableau
                       })
                       .catch(function (error) {
                           console.log('Erreur lors du chargement des dispositifs :', error);
                       });
                });
        };
        $scope.openModal = function (isEdit, phone) {
            var modalInstance = $uibModal.open({
                templateUrl: 'myModalContent2.html',
                controller: 'ModalController2',
                resolve: {
                    isEdit: function () {
                        return isEdit;
                    },
                    phone: function () {
                        return phone;
                    },
                    devices: function () {
                        return $scope.devices;
                    }
                }
            });

            modalInstance.result.then(function (result) {
                if (result !== undefined) {
                    if (isEdit) {
                        console.log('result:', result.DeviceId);
                        $scope.updatePhone(phone, result);

                    } else {
                        $scope.addPhone(result);
                    }
                }
            });
        };

        // ...

    }])

   .controller('ModalController2', ['$scope', '$uibModalInstance', '$http', 'isEdit', 'phone', 'devices', function ($scope, $uibModalInstance, $http, isEdit, phone, devices) {
       console.log("le phone en question est:", phone);
       
       $scope.isEdit = isEdit;
       $scope.inputPhoneNumber = phone ? phone.Number : '';
     
        $scope.devices = devices; 
       $scope.inputDevice = phone ? phone.DeviceName : '';
     
        $http.get('/api/devices')
            .then(function (response) {
                $scope.devices = response.data;
            })
            .catch(function (error) {
                console.log('Erreur lors de la r�cup�ration des dispositifs :', error);
            });
      
      
        $scope.savePhoneModal = function () {
            
            var numberPattern = /^\d{2}\/\d{6}$/;

            // V�rifiez si Number correspond au format attendu
            if (!numberPattern.test($scope.inputPhoneNumber)) {
                alert("Please enter a valid phone number in the format xx/xxxxxx, where x is number only!");
                return; // Sortir de la fonction si le format n'est pas valide
            }
            // Votre logique pour sauvegarder les modifications du t�l�phone ici
            // Utilisez $uibModalInstance.close() pour fermer le modal avec les donn�es modifi�es
            //var selectedDeviceId = null;
            var selectedDeviceId = $scope.inputDevice;

          
            // Cr�ation de l'objet newPhone avec l'ID du dispositif correspondant
            var newPhone = {
               // Id: phone.Id, // Assuming phone has an Id property
                Number: $scope.inputPhoneNumber,
                DeviceId: $scope.inputDevice // Utilisation de l'ID trouv�

            };

            if (!newPhone || !newPhone.Number || !newPhone.DeviceId ) {
                alert("Please fill in all fields for the new Phone number!");
                return; // Sortir de la fonction si des champs sont vides
            }
            console.log('newPhone:', newPhone);
            $uibModalInstance.close(newPhone);
        };

        $scope.closePhoneModal = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);
   