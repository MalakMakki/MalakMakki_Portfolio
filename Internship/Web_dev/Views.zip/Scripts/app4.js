angular.module('myApp2', ['ui.bootstrap'])

.controller('MainController2', ['$scope', '$http', '$uibModal', function ($scope, $http, $uibModal) {
    // ...

    // R�cup�rer la liste des dispositifs depuis la base de donn�es
    $http.get('/api/devices')
        .then(function (response) {
            $scope.devices = response.data;
        })
        .catch(function (error) {
            console.log('Erreur lors de la r�cup�ration des dispositifs :', error);
        });
      //  var deviceNameMapping = {};


    // ...
    $scope.phones = []; // Initialisez le tableau pour stocker les clients
    $http.get('/api/phones')
        .then(function (response) {
            $scope.phones = response.data;
        })
        .catch(function (error) {
            console.log('Erreur lors du chargement des t�l�phones :', error);
        });


    $scope.searchPhones = function () {
        // Appel de l'API avec les param�tres de recherche
        $http.get('/api/phones/search', { params: { phoneNumber: $scope.searchPhone, deviceId: $scope.deviceSelection } })
            .then(function (response) {
                $scope.phones = response.data;

                // V�rifier si le tableau est vide
                if ($scope.phones.length === 0) {
                    // Aucun r�sultat trouv�, vous pouvez effacer ou masquer la liste
                    $scope.noResultsFound = true;
                } else {
                    $scope.noResultsFound = false;
                }
            })
            .catch(function (error) {
                console.log('Erreur lors du chargement des clients :', error);
            });

    };


  /* $scope.SearchByNumber = function () {
        $http.get('/api/phones/filterByNumber', { params: { filter: $scope.searchPhone } })
            .then(function (response) {
              //  console.log('tu es dans response search!!!!');

             $scope.phones = response.data;

            })
            .catch(function (error) {
                console.error('Erreur lors de la r�cup�ration des t�l�phones :', error);
            });
    };
    $scope.SearchByDevice = function () {
        $http.get('/api/phones/filterByDevice', { params: { filter: $scope.deviceSelection } })
            .then(function (response) {
              //  console.log('tu es dans response search!!!!');

                $scope.phones = response.data;


            })
            .catch(function (error) {
                console.error('Erreur lors de la r�cup�ration des t�l�phones :', error);
            });
    };
    */

    $scope.updatePhone = function (phone,newPhone) {
        var updatedPhone = {
            Id: phone.Id,
            Number: newPhone.Number,
            DeviceId: newPhone.DeviceId
        };

        $http.post('/api/phones/update', updatedPhone)
            .then(function (response) {
                console.log(response.data); // Display success message
                // You can update your phone list or do other tasks here
                $http.get('/api/phones')
                    .then(function (response) {
                        $scope.phones = response.data;
                    })
                    .catch(function (error) {
                        console.log('Erreur lors du chargement des t�l�phones :', error);
                    });
            })
            .catch(function (error) {
                console.error(error.data); // Display error message
            });
    };


    $scope.openModal = function (isEdit, phone) {
        var modalInstance = $uibModal.open({
            templateUrl: 'myModalContent2.html',
            controller: 'ModalController2',
            resolve: {
                isEdit: function () {
                    return isEdit;
                },
                client: function () {
                    return phone;
                }
            }
        });
        modalInstance.result.then(function (result) {
            if (result !== undefined) {
                if (isEdit) {
                  
                    updatePhone(phone, result);
                } else {
                   
                    addPhone(result);
                }
            }
        });

    };
    

}])
    .controller('ModalController2', ['$scope', '$uibModalInstance', 'isEdit', 'phone', 'devices', function ($scope, $uibModalInstance, isEdit, phone, devices) {
        $scope.isEdit = isEdit;
        $scope.inputPhoneNumber = phone ? phone.Number : '';

        $scope.savePhoneModal = function () {
            // Recherche de l'ID du dispositif correspondant au nom s�lectionn�
            var selectedDeviceId = null;
            for (var i = 0; i < devices.length; i++) {
                if (devices[i].Name === $scope.inputDevice) {
                    selectedDeviceId = devices[i].Id;
                    break; // Sortir de la boucle d�s qu'une correspondance est trouv�e
                }
            }

            // Cr�ation de l'objet newPhone avec l'ID du dispositif correspondant
            var newPhone = {
                Id: phone.Id, // Assuming phone has an Id property
                Number: $scope.inputPhoneNumber,
                DeviceId: selectedDeviceId // Utilisation de l'ID trouv�
            };

            $uibModalInstance.close(newPhone);
        };

        $scope.closePhoneModal = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);
