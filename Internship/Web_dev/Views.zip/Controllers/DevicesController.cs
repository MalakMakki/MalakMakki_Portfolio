﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using WebApplication5.Models;
using System.Data.SqlClient;
using Microsoft.Ajax.Utilities;
using System.Data;

namespace WebApplication5.Controllers
{
    public class DevicesController : ApiController

    {

        [HttpGet]
        public IHttpActionResult GetAll()
        {
            //les 3 premiere ligne ici represente la connection establish
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<Device> devices = new List<Device>();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "GetAllDevices";
                SqlDataAdapter sqlDA = new SqlDataAdapter(command);
                DataTable dtDevice = new DataTable();
                connection.Open();
                sqlDA.Fill(dtDevice);
                connection.Close();
                foreach (DataRow dr in dtDevice.Rows)
                {
                    devices.Add(new Device
                    {
                        Id = Convert.ToInt32(dr["Id"]),
                        Name = dr["Name"].ToString()
                    });
                }
                return Ok(devices);
            }
        }

        [HttpGet]
        public IHttpActionResult GetFilteredDevices(string filter)
        {
            List<Device> devices = new List<Device>();
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT Id, Name FROM DeviceTab WHERE Name LIKE @Filter";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    command.Parameters.AddWithValue("@Filter", "%" + filter + "%");

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Device device = new Device
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Name = reader["Name"].ToString()
                            };
                            devices.Add(device);
                        }
                    }
                }
            }

            return Ok(devices);
        }

        [HttpPost]

        public IHttpActionResult Add_Device(Device newDevice)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand countCommand = connection.CreateCommand();
                countCommand.CommandType = CommandType.Text;
                countCommand.CommandText = "SELECT COUNT(*) FROM DeviceTab"; // Replace YourTableName with the actual table name

                connection.Open();
                int itemCount = (int)countCommand.ExecuteScalar();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "AddDevice"; // Assuming you have a stored procedure to add a device

                // Calculate the new Id based on item count
                int newDeviceId = itemCount + 1;

                // Set parameters
                command.Parameters.AddWithValue("@Id", newDeviceId);
                command.Parameters.AddWithValue("@Name", newDevice.Name);
                // Add other parameters as needed

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    return Ok("Device added successfully.");
                }
                else
                {
                    return BadRequest("Failed to add device.");
                }
            }
        }





        [HttpPut]
        public IHttpActionResult updateDevice(int id, Device updatedDevice)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "UpdateDevice"; // Supposons que vous ayez une procédure stockée pour mettre à jour un appareil

                // Ajoutez les paramètres nécessaires à la commande ici, par exemple :
                command.Parameters.AddWithValue("@Id", id);
                command.Parameters.AddWithValue("@Name", updatedDevice.Name);
                // Ajoutez d'autres paramètres selon les besoins

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0)
                {
                    return Ok("Device updated successfully.");
                }
                else
                {
                    return BadRequest("Failed to update device.");
                }
            }
        }




        /* private static List<Device> devices = new List<Device>
         {
             new Device { Id = 1, Name = "Device 1" },
             new Device { Id = 2, Name = "Device 2" },
             new Device { Id = 3, Name = "Phone 1" },
             new Device { Id = 4, Name = "Phone 2" },
             new Device { Id = 5, Name = "Laptop 1" },
             new Device { Id = 6, Name = "Laptop 2" },
             new Device { Id = 7, Name = "Mouse" }

             // Add other data here...
         };

        [HttpGet]
        public IHttpActionResult GetAllDevices()
        {


            return Ok(devices);


        }

        [HttpGet]
        public IHttpActionResult GetFilteredDevices(string search)
        {

            var filteredDevices = devices.Where(device => device.Name.Contains(search)).ToList();
            return Ok(filteredDevices);
        }

        [HttpPost]

        public IHttpActionResult AddDevice(Device device)
        {
            // Assuming your devices list is named "devices"
            device.Id = devices.Count + 1; // Assign a new ID
            devices.Add(device);

            return Ok(device);
        }

        [HttpPut]

        public IHttpActionResult UpdateDevice(int id, Device updatedDevice)
        {
            // Assuming your devices list is named "devices"
            var existingDevice = devices.FirstOrDefault(d => d.Id == id);

            if (existingDevice == null)
            {
                return NotFound();
            }

            existingDevice.Name = updatedDevice.Name; // Update device name

            return Ok(existingDevice);
        }*/




    }


}
