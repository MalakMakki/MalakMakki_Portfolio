﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication5.Data;

namespace WebApplication5.Controllers
{
    public class DevDataController : Controller
    {
        devices_Data dev_data = new devices_Data();

        // GET: DevData
        public ActionResult Index()
        {
            var devices = dev_data.GetAllDev(); 
            return View(devices);
        }

        // GET: DevData/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: DevData/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: DevData/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: DevData/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: DevData/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: DevData/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: DevData/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
