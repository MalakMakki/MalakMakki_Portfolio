﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using WebApplication5.Models;
using System.Web.Mvc;

namespace WebApplication5.Data
{
    public class devices_Data
    {
        string connectString = ConfigurationManager.ConnectionStrings["adoConnectionstring"].ToString();

        
        public  List<Device> GetAllDev()
        {
            List<Device> devices = new List<Device>();
            using (SqlConnection connection = new SqlConnection(connectString))
            {
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "GetAllDevices";
                SqlDataAdapter sqlDA = new SqlDataAdapter(command);
                DataTable dtDevice = new DataTable();
                connection.Open();
                sqlDA.Fill(dtDevice);
                connection.Close();
                foreach (DataRow dr in dtDevice.Rows)
                {
                    devices.Add(new Device
                    {
                        Id = Convert.ToInt32(dr["Id"]),
                        Name = dr["Name"].ToString()
                    }) ;
                }

            }
            
            return devices;
        }
    }
}