﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Routing;


namespace WebApplication5
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            config.Routes.MapHttpRoute(
              name: "Add_Device",
              routeTemplate: "api/devices",
              defaults: new { controller = "DevicesController", action = "Add_Device" }
          );


            config.Routes.MapHttpRoute(
             name: "GetAll",
            routeTemplate: "api/devices",
            defaults: new { controller = "DevicesController", action = "GetAll" }
            );


           config.Routes.MapHttpRoute(
               name: "GetFilteredDevices",
               routeTemplate: "api/devices/filter",
               defaults: new { controller = "DevicesController", action = "GetFilteredDevices" }
           );

          
            config.Routes.MapHttpRoute(
               name: "updateDevice",
               routeTemplate: "api/devices/{id}",
               defaults: new { controller = "DevicesController", action = "updateDevice" }
           );




            config.Routes.MapHttpRoute(
                name: "GetAllClients",
                routeTemplate: "api/clients",
                defaults: new { controller = "ClientsController", action = "GetAll" }
                //constraints: new { httpMethod = new HttpMethodConstraint(HttpMethod.Get) }
            );

            /*config.Routes.MapHttpRoute(
                name: "GetFilteredClients",
                routeTemplate: "api/clients/filter/{filter}/{Type}",
                defaults: new { controller = "ClientsController", action = "GetFilteredClients" }
                //constraints: new { httpMethod = new HttpMethodConstraint(HttpMethod.Get) }
            );*/

         
            
            config.Routes.MapHttpRoute(
                name: "GetFilteredClientsByType",
                routeTemplate: "api/clients/filterByType/{filter}",
                defaults: new { controller = "ClientsController", action = "GetFilteredClientsByType" }
            );



        }
    }
}
            
