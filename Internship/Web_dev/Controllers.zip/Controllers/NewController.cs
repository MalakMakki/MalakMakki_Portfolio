﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{
    public class NewController: ApiController
    {

        [HttpGet]
        public IHttpActionResult GetAll()
        {
            //les 3 premiere ligne ici represente la connection establish
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<Device> devices = new List<Device>();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "GetAllDevices";
                SqlDataAdapter sqlDA = new SqlDataAdapter(command);
                DataTable dtDevice = new DataTable();
                connection.Open();
                sqlDA.Fill(dtDevice);
                connection.Close();
                foreach (DataRow dr in dtDevice.Rows)
                {
                    devices.Add(new Device
                    {
                        Id = Convert.ToInt32(dr["Id"]),
                        Name = dr["Name"].ToString()
                    });
                }
                return Ok(devices);

                /*connection.Open();
                string storedPocedureName = "GetAllDevices";*/

                /*using (SqlCommand command = new SqlCommand(storedPocedureName, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        List<Device> devices = new List<Device>();
                        while (reader.Read())
                        {
                            Device device = new Device()
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                Name = reader.GetString(reader.GetOrdinal("Name"))
                            };
                            devices.Add(device);
                        }
                        return Ok(devices);
                    }
                }*/
            }
        }

    }
}