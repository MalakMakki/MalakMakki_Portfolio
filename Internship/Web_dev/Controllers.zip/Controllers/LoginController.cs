﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication5.Models;

using System.Web.Mvc;

namespace WebApplication5.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        /*public ActionResult login()
        {
            return View();
        }*/
        /*public ActionResult Login()
        {
            return View("_Login");
        }*/
        public ActionResult Login()
        {
            return View();
        }
    }


}