﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication5.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {

            return View();
        }

        public ActionResult Contact()
        {

            return View();
        }

        
            public ActionResult Reserve()
            {

                return View();
            }

        public ActionResult ClientReport()
        {

            return View();
        }

        public ActionResult DeviceReservationReport()
        {

            return View();
        }
        public ActionResult HomePage()
        {

            return View();
        }

        public ActionResult loginPage()
        {

            return View();
        }
    }
}