﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http;
using WebApplication5.Models;


namespace WebApplication5.Controllers
{
    public class PhoneController:ApiController
    {

        [HttpGet]
        [Route("api/phones")]
        public IHttpActionResult GetAllPhones()
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<PhoneWithName> phones = new List<PhoneWithName>();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "GetAllPhonesWithDeviceName"; // Modifiez le nom de votre procédure stockée

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        phones.Add(new PhoneWithName
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Number = reader["Number"].ToString(),
                            DeviceName = reader["DeviceName"].ToString() // Récupérez le nom du dispositif
                        });
                    }
                }

                connection.Close();

                if (phones.Count > 0)
                {
                    return Ok(phones);
                }
                else
                {
                    return NotFound();
                }
            }
        }

       


       [HttpGet]
        [Route("api/phones/search")]
        public IHttpActionResult SearchPhones(string phoneNumber = null, int? deviceId = null)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<PhoneWithName> phones = new List<PhoneWithName>();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SearchPhone"; // Nom de la procédure stockée

                // Ajoutez les paramètres nécessaires à la commande
                command.Parameters.AddWithValue("@PhoneNumber", string.IsNullOrEmpty(phoneNumber) ? DBNull.Value : (object)phoneNumber);
                command.Parameters.AddWithValue("@DeviceId", deviceId.HasValue ? (object)deviceId.Value : DBNull.Value);

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        phones.Add(new PhoneWithName
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Number = reader["Number"].ToString(),
                            DeviceName = reader["DeviceName"].ToString()
                        });
                    }
                }

                connection.Close();

                if (phones.Count > 0)
                {
                    return Ok(phones);
                }
                else
                {
                    return NotFound();
                }
            }
        }
       

       [HttpGet]
        [Route("api/phones/filterByNumber")]

        public IHttpActionResult GetPhones(string filter)
        {
            List<Phone> phones = new List<Phone>();
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT Id, Number,DeviceId FROM PhoneTab WHERE Number LIKE @Filter";
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    command.Parameters.AddWithValue("@Filter", "%" + filter + "%");

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Conversion de l'entier en énumération


                            Phone phone = new Phone
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Number = reader["Number"].ToString(),
                                DeviceId = Convert.ToInt32(reader["DeviceId"]),
                                


                            };
                            phones.Add(phone);
                        }
                    }
                }
            }

            return Ok(phones);
        }
        /*  [HttpPut]
          [Route("api/phones/update")]
          public IHttpActionResult UpdatePhone(  Phone updatedPhone)
          {
              string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

              try
              {
                  using (SqlConnection connection = new SqlConnection(connectionString))
                  {
                      // Ouvrez la connexion et exécutez votre procédure stockée
                      connection.Open();

                      SqlCommand command = connection.CreateCommand();
                      command.CommandType = CommandType.StoredProcedure;
                      command.CommandText = "UpdatePhone"; // Remplacez par le nom de votre procédure stockée

                      // Ajoutez les paramètres nécessaires à la commande
                      command.Parameters.AddWithValue("@PhoneId", updatedPhone.Id);
                      command.Parameters.AddWithValue("@PhoneNumber", updatedPhone.Number);
                      command.Parameters.AddWithValue("@DeviceId", updatedPhone.DeviceId);

                      command.ExecuteNonQuery();
                  }

                  return Ok("Téléphone mis à jour avec succès");
              }
              catch (Exception ex)
              {
                  return BadRequest("Échec de la mise à jour du téléphone : " + ex.Message);
              }
          }*/

        [HttpPut]
        [Route("api/phones/update")]
        public IHttpActionResult UpdatePhone(Phone updatedPhone)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand command = connection.CreateCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "UpdatePhone3"; // Assurez-vous que le nom de la procédure stockée est correct

                    // Assurez-vous que les noms de paramètres correspondent à ceux de la procédure stockée
                    command.Parameters.AddWithValue("@PhoneId", updatedPhone.Id);
                    command.Parameters.AddWithValue("@PhoneNumber", updatedPhone.Number);
                    command.Parameters.AddWithValue("@DeviceId", updatedPhone.DeviceId);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return Ok("Téléphone mis à jour avec succès");
                    }
                    else
                    {
                        return BadRequest("Aucun enregistrement mis à jour");
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Échec de la mise à jour du téléphone : " + ex.Message);
            }
        }


        [HttpPost]
        
        [Route("api/phones/add")]

        public IHttpActionResult Add_Phone(Phone newPhone)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand countCommand = connection.CreateCommand();
                countCommand.CommandType = CommandType.Text;
                countCommand.CommandText = "SELECT COUNT(*) FROM PhoneTab"; // Replace YourTableName with the actual table name

                connection.Open();
                int itemCount = (int)countCommand.ExecuteScalar();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "AddPhone"; // Assuming you have a stored procedure to add a device

                // Calculate the new Id based on item count
                int newPhoneId = itemCount + 1;

                // Set parameters
                command.Parameters.AddWithValue("@Id", newPhoneId);
                command.Parameters.AddWithValue("@Number", newPhone.Number);
                command.Parameters.AddWithValue("@DeviceId", newPhone.DeviceId);

                // Add other parameters as needed

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    return Ok("Phone added successfully.");
                }
                else
                {
                    return BadRequest("Failed to add Phone.");
                }
            }
        }





    }
}