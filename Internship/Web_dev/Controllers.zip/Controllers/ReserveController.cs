﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{


    public class ReserveController : ApiController
    {

        [HttpGet]
        [Route("api/reservations")]
        public IHttpActionResult GetAllReservations()
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<PhoneNumberReservation> reservations = new List<PhoneNumberReservation>();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "GetAllPhoneNumberReservation"; // Modifiez le nom de votre procédure stockée

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        reservations.Add(new PhoneNumberReservation
                        {
                            Id = Convert.ToInt32(reader["ID"]),
                            ClientName = reader["ClientName"].ToString(),
                            PhoneNumber = reader["PhoneNumber"].ToString(),
                            BED = Convert.ToDateTime(reader["BED"]),
                            EED = reader["EED"] != DBNull.Value ? Convert.ToDateTime(reader["EED"]) : (DateTime?)null
                        });

                    }
                }

                connection.Close();

                if (reservations.Count > 0)
                {
                    return Ok(reservations);
                }
                else
                {
                    return NotFound();
                }
            }
        }


        /* [HttpGet]
         [Route("api/reservations/filter")]
         public IHttpActionResult GetAllReservations(int? phoneId = null)
         {
             string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

             using (SqlConnection connection = new SqlConnection(connectionString))
             {
                 List<PhoneNumberReservation> reservations = new List<PhoneNumberReservation>();

                 SqlCommand command = connection.CreateCommand();
                 command.CommandType = CommandType.StoredProcedure;
                 command.CommandText = "FilterByNumber"; // Modifiez le nom de votre procédure stockée

                 command.Parameters.AddWithValue("@PhoneNumberId", phoneId.HasValue ? (object)phoneId.Value : DBNull.Value);


                 connection.Open();

                 using (SqlDataReader reader = command.ExecuteReader())
                 {
                     while (reader.Read())
                     {
                         // Ajoutez des conditions ici pour filtrer les réservations en fonction des paramètres de recherche


                             reservations.Add(new PhoneNumberReservation
                             {
                                 Id = Convert.ToInt32(reader["ID"]),
                                 ClientName = reader["ClientName"].ToString(),
                                 PhoneNumber = reader["PhoneNumber"].ToString(),
                                 BED = Convert.ToDateTime(reader["BED"]),
                                 EED = reader["EED"] != DBNull.Value ? Convert.ToDateTime(reader["EED"]) : (DateTime?)null
                             });

                     }
                 }

                 connection.Close();

                 if (reservations.Count > 0)
                 {
                     return Ok(reservations);
                 }
                 else
                 {
                     return NotFound();
                 }
             }
         }*/
        /* [HttpGet]
         [Route("api/reservations/filter")]
         public IHttpActionResult FilterReservations(int? phoneNumber, int? type)
         {
             string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

             using (SqlConnection connection = new SqlConnection(connectionString))
             {
                 connection.Open();

                 string query = "SELECT r.Id,r.clientId,r.phoneNumberId,r.BED,r.EED, c.Type FROM ReserveTab r " +
                                "INNER JOIN PhoneTab p ON r.phoneNumberId = p.Id " +
                                "INNER JOIN ClientTab c ON r.clientId = c.Id " +
                                "WHERE (@PhoneNumber IS NULL OR p.Id = @PhoneNumber) " +
                                "AND (@Type IS NULL OR c.Type = @Type)";

                 using (SqlCommand command = new SqlCommand(query, connection))
                 {
                     command.Parameters.Add("@PhoneNumber", SqlDbType.Int).Value = phoneNumber.HasValue ? phoneNumber.Value : (object)DBNull.Value;
                     command.Parameters.Add("@Type", SqlDbType.Int).Value = type.HasValue ? type.Value : (object)DBNull.Value;

                     using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                     {
                         DataTable dataTable = new DataTable();
                         adapter.Fill(dataTable);

                         return Ok(dataTable);
                     }
                 }
             }
         }
        */
        /*  [HttpGet]
          [Route("api/reservations/filter")]
          public IHttpActionResult FilterReservations(int? phoneNumber = null, int? type = null)
          {
              string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

              using (SqlConnection connection = new SqlConnection(connectionString))
              {

                  connection.Open();

                  string query = "SELECT r.Id, r.clientId, r.phoneNumberId, r.BED, r.EED, c.Type FROM ReserveTab r " +
                                 "INNER JOIN PhoneTab p ON r.phoneNumberId = p.Id " +
                                 "INNER JOIN ClientTab c ON r.clientId = c.Id " +
                                 "WHERE 1 = 1"; // Condition de base

                  if (phoneNumber.HasValue)
                  {
                      query += " AND p.Id = @PhoneNumber";
                  }

                  if (type.HasValue)
                  {
                      query += " AND c.Type = @Type";
                  }

                  using (SqlCommand command = new SqlCommand(query, connection))
                  {
                      if (phoneNumber.HasValue)
                      {
                          command.Parameters.Add("@PhoneNumber", SqlDbType.Int).Value = phoneNumber.Value;
                      }

                      if (type.HasValue)
                      {
                          command.Parameters.Add("@Type", SqlDbType.Int).Value = type.Value;
                      }

                       using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                         {
                             DataTable dataTable = new DataTable();
                             adapter.Fill(dataTable);

                             return Ok(dataTable);
                         }



                  }


              }
          }*/

        [HttpGet]
        [Route("api/reservations/filter")]
        public IHttpActionResult FilterReservations(int? phoneNumber = null, int? type = null)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("FilterReservationsNew", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Add parameters to the stored procedure
                    command.Parameters.Add("@PhoneNumber", SqlDbType.Int).Value = (object)phoneNumber ?? DBNull.Value;
                    command.Parameters.Add("@Type", SqlDbType.Int).Value = (object)type ?? DBNull.Value;

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        return Ok(dataTable);
                    }
                }
            }
        }



        [HttpPost]
        [Route("api/reservations/add")]
        public IHttpActionResult AddReservation(PhoneNumberReservation newReserve)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand countCommand = connection.CreateCommand();
                countCommand.CommandType = CommandType.Text;
                countCommand.CommandText = "SELECT COUNT(*) FROM ReserveTab"; // Replace YourTableName with the actual table name

                connection.Open();
                int itemCount = (int)countCommand.ExecuteScalar();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "AddReserve";

                // Calculate the new Id based on item count
                int newReserveId = itemCount + 1;

                // Set parameters
                command.Parameters.AddWithValue("@Id", newReserveId);
                command.Parameters.AddWithValue("@ClientName", newReserve.ClientName);
                command.Parameters.AddWithValue("@PhoneNumber", newReserve.PhoneNumber);
                command.Parameters.AddWithValue("@BED", newReserve.BED);
                if (newReserve.EED != null)
                {
                    command.Parameters.AddWithValue("@EED", newReserve.EED);
                }
                else
                {
                    command.Parameters.AddWithValue("@EED", DBNull.Value);
                }


                // Add other parameters as needed

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    return Ok("Reservation added successfully.");
                }
                else
                {
                    return BadRequest("Failed to add Reservation.");
                }
            }
        }


        [HttpPost]
        [Route("api/reservations/check")]
        public IHttpActionResult checkReservation(string ClientName)
        {
            bool hasReservation = false;

            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "CheckClientReservation";


                command.Parameters.AddWithValue("@ClientName", ClientName);
                SqlParameter hasReservationParam = command.Parameters.Add("@HasReservation", SqlDbType.Bit);
                hasReservationParam.Direction = ParameterDirection.Output;

                command.ExecuteNonQuery();

                hasReservation = (bool)hasReservationParam.Value;


                return Ok(hasReservation);

            }
        }


       /* [HttpGet]
        [Route("api/reservations/reservedForClient")]
        public IHttpActionResult CheckReservedNumberForClient(string ClientName)
        {
            List<string> reservedPhoneNumbers = new List<string>();

            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("GetReservedPhoneNumbersByClientName3", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ClientName", ClientName);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string phoneNumber = reader.GetString(0); // Adapter ce code en fonction de la structure de votre base de données
                            reservedPhoneNumbers.Add(phoneNumber);
                        }
                    }
                }
            }

            // Vous avez maintenant la liste des numéros de téléphone réservés, vous pouvez les renvoyer en réponse HTTP
            return Ok(reservedPhoneNumbers);
        }*/


        [HttpGet]
        [Route("api/reservations/reservedNumberForClient")]
        public IHttpActionResult CheckReservedPhoneNumberForClient(string ClientName)
        {

            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<Phone> phones = new List<Phone>();

                connection.Open();


                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "GetReservedPhoneNumbersByClientName4"; 

                command.Parameters.AddWithValue("@ClientName", ClientName);


                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        phones.Add(new Phone
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Number = reader["Number"].ToString(),
                            DeviceId = Convert.ToInt32(reader["DeviceId"]) // Récupérez le nom du dispositif
                        });
                    }
                }

                connection.Close();
                Console.WriteLine(phones);
                if (phones.Count > 0)
                {
                    return Ok(phones);
                }
                else
                {
                    return NotFound();
                }
            }
        }



        [HttpPost]
        [Route("api/reservations/update")]
        public IHttpActionResult UpdateReservation(PhoneNumberReservation newReserve)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
               

                connection.Open();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "UpdateReserve";


                // Set parameters
                command.Parameters.AddWithValue("@ClientName", newReserve.ClientName);
                command.Parameters.AddWithValue("@PhoneNumber", newReserve.PhoneNumber);
                command.Parameters.AddWithValue("@EED", newReserve.EED);
                

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    return Ok("Reservation updated successfully.");
                }
                else
                {
                    return BadRequest("Failed to update Reservation.");
                }
            }
        }

        [HttpGet]
        [Route("api/reserves/report")]
        public IHttpActionResult GetNumbersForReport()
        {
            // Appeler la méthode ExecuteStoredProcedure pour obtenir les résultats de la procédure stockée.
            DataTable results = ExecuteStoredProcedure();

            // Traitez les résultats comme vous le souhaitez (par exemple, convertissez-les en liste d'objets JSON).
            // Ici, nous supposons que vous convertissez les résultats en une liste de dictionnaires.
            List<Dictionary<string, object>> resultList = new List<Dictionary<string, object>>();
            foreach (DataRow row in results.Rows)
            {
                Dictionary<string, object> dict = new Dictionary<string, object>();
                foreach (DataColumn col in results.Columns)
                {
                    dict[col.ColumnName] = row[col];
                }
                resultList.Add(dict);
            }

            return Ok(resultList);
        }


        private string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

        public DataTable ExecuteStoredProcedure()
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetNumbersForReport2", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    connection.Open();

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            return dataTable;
        }




        /*        [HttpGet]
                [Route("api/reserves/filter")]
                public IHttpActionResult GetNumbersForReport(string deviceName )
                {
                    Console.WriteLine("Device Name: " + deviceName); // Ajoutez cette ligne pour vérifier la valeur du dispositif

                    // Appeler la méthode ExecuteStoredProcedure pour obtenir les résultats de la procédure stockée.
                    DataTable results = ExecuteStoredProcedure(deviceName);

                    // Traitez les résultats comme vous le souhaitez (par exemple, convertissez-les en liste d'objets JSON).
                    // Ici, nous supposons que vous convertissez les résultats en une liste de dictionnaires.
                    List<Dictionary<string, object>> resultList = new List<Dictionary<string, object>>();
                    foreach (DataRow row in results.Rows)
                    {
                        Dictionary<string, object> dict = new Dictionary<string, object>();
                        foreach (DataColumn col in results.Columns)
                        {
                            dict[col.ColumnName] = row[col];
                        }
                        resultList.Add(dict);
                    }

                    return Ok(resultList);
                }*/
        [HttpGet]
        [Route("api/reserves/filter")]
        public IHttpActionResult GetNumbersForReport(string deviceName = "")
        {
            Console.WriteLine("Device Name: " + deviceName); // Ajoutez cette ligne pour vérifier la valeur du dispositif

            DataTable results = null;

            // Si deviceName est vide, renvoyez tous les résultats sans filtre
            if (string.IsNullOrEmpty(deviceName))
            {
                results = ExecuteStoredProcedure(string.Empty);
            }
            else
            {
                // Sinon, appliquez le filtre en fonction de deviceName
                results = ExecuteStoredProcedure(deviceName);
            }

            // Traitez les résultats comme vous le souhaitez (par exemple, convertissez-les en liste d'objets JSON).
            // Ici, nous supposons que vous convertissez les résultats en une liste de dictionnaires.
            List<Dictionary<string, object>> resultList = new List<Dictionary<string, object>>();
            foreach (DataRow row in results.Rows)
            {
                Dictionary<string, object> dict = new Dictionary<string, object>();
                foreach (DataColumn col in results.Columns)
                {
                    dict[col.ColumnName] = row[col];
                }
                resultList.Add(dict);
            }

            return Ok(resultList);
        }



        public DataTable ExecuteStoredProcedure(string deviceName)
        {
            DataTable dataTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("GetNumbersForReport3", connection)) // Utilisez la nouvelle procédure stockée GetNumbersForReport3
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Ajoutez un paramètre pour le nom du dispositif
                    command.Parameters.AddWithValue("@deviceName", deviceName);

                    connection.Open();

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }
            return dataTable;
        }


    }
}