﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using WebApplication5.Models;


namespace WebApplication5.Controllers
{
    public class ClientsController : ApiController
    {
        [HttpGet]
        public IHttpActionResult GetAll()
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<Client> clients = new List<Client>();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "GetAllClients"; // Utilisez le nom de votre procédure stockée pour obtenir tous les clients
                SqlDataAdapter sqlDA = new SqlDataAdapter(command);
                DataTable dtClient = new DataTable();
                connection.Open();
                sqlDA.Fill(dtClient);
                connection.Close();
                foreach (DataRow dr in dtClient.Rows)
                {
                    client_Type typeValue = (client_Type)Convert.ToInt32(dr["Type"]); // Conversion de l'entier en énumération
                    clients.Add(new Client
                    {
                        Id = Convert.ToInt32(dr["Id"]),
                        Name = dr["Name"].ToString(),
                        Type = typeValue,
                      //  Birthdate = Convert.ToDateTime(dr["Birthdate"])
                       Birthdate = dr["Birthdate"] != DBNull.Value ? Convert.ToDateTime(dr["Birthdate"]) : (DateTime?)null

                    });
                }
                return Ok(clients);
            }
        }



        [HttpGet]
        [Route("api/clients/filter")]
        public IHttpActionResult FilterClients(string filter = null, int? type = null)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<Client> clients = new List<Client>();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "FilterClientsNew"; // Nom de la procédure stockée

                // Ajoutez les paramètres nécessaires à la commande
                command.Parameters.AddWithValue("@NameFilter", string.IsNullOrEmpty(filter) ? DBNull.Value : (object)("%" + filter + "%"));
                command.Parameters.AddWithValue("@TypeFilter", type.HasValue ? (object)type.Value : DBNull.Value);

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        client_Type typeValue = (client_Type)Convert.ToInt32(reader["Type"]);
                        Client client = new Client
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Name = reader["Name"].ToString(),
                            Type = typeValue,
                            Birthdate = reader["Birthdate"] != DBNull.Value ? Convert.ToDateTime(reader["Birthdate"]) : (DateTime?)null
                        };
                        clients.Add(client);
                    }
                }

                connection.Close();

                return Ok(clients);
            }
        }



       

        

        [HttpPost]
        [Route("api/clients/add")]
        public IHttpActionResult AddClient(Client newClient)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand countCommand = connection.CreateCommand();
                countCommand.CommandType = CommandType.Text;
                countCommand.CommandText = "SELECT COUNT(*) FROM ClientTab";

                    connection.Open();
                int itemCount = (int)countCommand.ExecuteScalar();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "AddClient1"; // Nom de la procédure stockée pour l'ajout

                int newClientId = itemCount + 1;

                // Ajoutez les paramètres nécessaires ici, par exemple
                command.Parameters.AddWithValue("@Id", newClientId);
                command.Parameters.AddWithValue("@Name", newClient.Name);
                command.Parameters.AddWithValue("@Type", (int)newClient.Type);
                //command.Parameters.AddWithValue("@Birthdate", newClient.Birthdate);
                if (newClient.Type == client_Type.individual)
                {
                    command.Parameters.AddWithValue("@Birthdate", newClient.Birthdate);
                }
                else
                {
                    command.Parameters.AddWithValue("@Birthdate", DBNull.Value);
                }
                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected>0)
                {
                    return Ok("Client added successfully.");
                }
                else
                {
                    return BadRequest("Failed to add client.");
                }
            }
        }


        [HttpPut]
        [Route("api/clients/update")]
        public IHttpActionResult UpdateClient([FromBody] Client client)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "UpdateClientWithDate"; // Nom de la procédure stockée pour la mise à jour

                // Ajoutez les paramètres nécessaires ici, par exemple :
                command.Parameters.AddWithValue("@Id", client.Id); // ID du client à mettre à jour
                command.Parameters.AddWithValue("@Name", client.Name);
                command.Parameters.AddWithValue("@Type", (int)client.Type);
                //command.Parameters.AddWithValue("@Birthdate", client.Birthdate);
                if (client.Type == client_Type.individual)
                {
                    command.Parameters.AddWithValue("@Birthdate", client.Birthdate);
                }
                else
                {
                    command.Parameters.AddWithValue("@Birthdate", DBNull.Value);
                }
                // Exécutez la procédure stockée
                command.ExecuteNonQuery();

                return Ok("Client modifié avec succès");
            }
        }




        [HttpGet]
        [Route("api/clients/getcount")]

        public IHttpActionResult GetClientCounts()
        {
            try
            {
                string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    var command = new SqlCommand("GetClientCounts", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    // Ajoutez ici les paramètres nécessaires pour votre Stored Procedure, si applicable.

                    var reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        var clientCount = new ClientCount
                        {
                            IndividualCount = Convert.ToInt32(reader["IndividualCount"]),
                            OrganizationCount = Convert.ToInt32(reader["OrganizationCount"])
                        };

                        return Ok(clientCount);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }


        [HttpGet]
        [Route("api/clients/unreserve")]
        public IHttpActionResult GetUnreservedPhones()
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                List<Phone> phones = new List<Phone>();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "SelectAvailableNumero2"; // Modifiez le nom de votre procédure stockée

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        phones.Add(new Phone
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Number = reader["Number"].ToString(),
                            DeviceId = Convert.ToInt32(reader["DeviceId"]) // Récupérez le nom du dispositif
                        });
                    }
                }

                connection.Close();
                Console.WriteLine( phones);
                if (phones.Count > 0)
                {
                    return Ok(phones);
                }
                else
                {
                    return NotFound();
                }
            }
        }

        string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";




    }

}

