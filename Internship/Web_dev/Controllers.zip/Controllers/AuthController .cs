﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http;
using WebApplication5.Models;
using System.Net;

namespace WebApplication5.Controllers
{


    public class AuthController : ApiController
    {


        string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";



        [HttpPost]
        [Route("api/login/add")]
        public IHttpActionResult SignUp(Login user)
        {


            if (user == null)
            {
                return BadRequest("Les données de l'utilisateur sont nulles.");
            }
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "AddUser";



                command.Parameters.AddWithValue("@Username", user.Username);
                command.Parameters.AddWithValue("@Password", user.Password);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    return Ok("User added successfully.");
                }
                else
                {
                    return BadRequest("Failed to add User.");
                }

            }
        }

        [HttpPost]
        [Route("api/login/compare")]
        public IHttpActionResult CompareUsernamePassword(Login userData)
        {
            string connectionString = "data source=DESKTOP-L5T0M6D\\SQL2014; database=Device; integrated security=true";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand("CompareUsernamePassword", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@Username", SqlDbType.NVarChar, 50).Value = userData.Username;
                    command.Parameters.Add("@Password", SqlDbType.NVarChar, 50).Value = userData.Password;

                    int userCount = (int)command.ExecuteScalar();

                    if (userCount == 1)
                    {
                        return Ok("Login successful");
                    }
                    else
                    {
                        return BadRequest("Username or password is invalid");
                    }
                }
            }
        }
    }
}